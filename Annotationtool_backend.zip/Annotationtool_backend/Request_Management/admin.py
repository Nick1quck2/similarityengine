from django.contrib import admin
from .models import (RequestPlatform,Annotationclasses,  Assign_Annotation_Tasks,
    Assign_Verification_Tasks,
    Task_Annotation_User,
    Task_Verification_User ,Labelation,Label_data,Track,PersonAttributes)
# Register your models here.

admin.site.register(RequestPlatform)
admin.site.register(Annotationclasses)
admin.site.register(Assign_Annotation_Tasks)
admin.site.register(Task_Annotation_User)
admin.site.register(Assign_Verification_Tasks)
admin.site.register(Task_Verification_User)
admin.site.register(Labelation)
admin.site.register(Label_data)
admin.site.register(Track)
admin.site.register(PersonAttributes)


