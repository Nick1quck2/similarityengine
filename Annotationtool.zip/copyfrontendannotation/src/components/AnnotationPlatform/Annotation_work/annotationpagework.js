import React, { useState, useEffect } from "react";
import { useParams, useHistory } from "react-router-dom";
import axios from "axios";
import ReactImageAnnotate from "react-image-annotate";

const AnnotationMakingPage = () => {
  const { request_id, request_name, x_number, y_number, p_index, status } =
    useParams();
  const history = useHistory();
  const token = localStorage.getItem("access_token");
  const user = localStorage.getItem("username");

  const [classes, setClasses] = useState([]);
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch annotation classes
    const fetchClasses = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8000/request/requestplatform/${request_id}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setClasses(response.data.data.classes || []);
      } catch (error) {
        console.error("Error fetching classes:", error);
      }
    };

    // Fetch images
    const fetchImages = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8000/request/images/${request_name}?x_number=${x_number}&y_number=${y_number}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        const imageList = response.data.data.map((image) => ({
          src: `http://localhost:8000/${image.url}`,
          name: image.filename, // Assuming each dictionary has `name`
        }));
        
        setImages(imageList);
      } catch (error) {
        console.error("Error fetching images:", error);
      }
    };

    // Fetch both classes and images
    const fetchData = async () => {
      setLoading(true);
      await fetchClasses();
      await fetchImages();
      setLoading(false);
    };

    fetchData();
  }, [request_id, request_name, x_number, y_number, token]);

  const handleSaveAnnotations = async (output) => {
    try {
      // Prepare the data for Labelation and Label_data
      const xNum = parseInt(x_number, 10);
      const yNum = parseInt(y_number, 10);
      const imageRange = [...Array(yNum - xNum + 1).keys()].map((i) => i + xNum);
      
      const annotations = output.images
      .map((image, index) => {
        // Only include images that have regions
        if (!image.regions || image.regions.length === 0) {
          console.log(`Skipping ${image.name} as it has no regions.`);
          return null; // Return null for images with no regions
        }
        return {
          Image_name: image.name, // Image name
          Image_number: imageRange[index], // Assign Image_number using the x_number to y_number range
          regions: image.regions.map((region) => ({
            id: region.id,
            class_name: region.cls, // Class name
            color: region.color,
            x: region.x, // Bounding box x
            y: region.y, // Bounding box y
            w: region.w, // Bounding box width
            h: region.h, // Bounding box height
          })),
        };
      })
      .filter((annotation) => annotation !== null); // Remove null entries
    
  
      // Loop through each annotation to save Labelation and associated Label_data
      for (const annotation of annotations) {
        const date_annotated = new Date().toISOString().split('T')[0]; // Gets today's date in YYYY-MM-DD format

        const labelationResponse = await axios.post(
          `http://localhost:8000/request/labelation/?linked=${request_id}&Image_number=${annotation.Image_number}`,
          {
            linked: request_id, // RequestPlatform ID
            Image_name: annotation.Image_name, // Image name
            Image_number: annotation.Image_number, // Image number
            annotated_by: user, // Replace with the current user's username
            date_annotated: date_annotated
          },  
          {                 
            headers: {
              Authorization: `Bearer ${token}`,
            },  
          }
        ); 
  
        const labelationId = labelationResponse.data.data.id; // ID of created Labelation
  
        // Save Label_data for the regions (POST, PUT, DELETE based on region state)
        for (const region of annotation.regions) {
  
            // Create new region (POST)
            await axios.post(
              `http://localhost:8000/request/label-data/`,
              {
                linked: labelationId, // Link to the created Labelation
                class_name: region.class_name, // Class name
                color: region.color,
                region_id: region.id,
                x: region.x,
                y: region.y,
                w: region.w,
                h: region.h,
              },
              {
                headers: {
                  Authorization: `Bearer ${token}`,
                },
              }
            );
          
        }
      }
  
      alert("All annotations saved successfully!");
      history.push(
        `/request_dashboard/${request_id}/${request_name}/${p_index}/${status}/annotation-tasks`
      );
    } catch (error) {
      console.error("Error saving annotations:", error);
      alert("Failed to save annotations.");
    }
  };
  
  
  

  if (loading) {
    return <div>Loading...</div>;
  }


  return (
    <>  
   <ReactImageAnnotate
      labelImages
      regionClsList={classes}
      images={images}
      onExit={handleSaveAnnotations}
    />
    </> 
  );
};

export default AnnotationMakingPage;
