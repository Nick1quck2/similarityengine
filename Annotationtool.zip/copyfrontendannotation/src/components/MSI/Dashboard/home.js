import React, { useEffect, useState } from "react";
import "./home.css";
import Annotationclasses from "./home_right_side_panel/Annotation_classes/annotation_classes_work"
import Annotators from "./home_right_side_panel/Annotators/annotators_work"
import Requests from "./home_right_side_panel/Requests/requests_work"
import { useHistory } from 'react-router-dom';  // Corrected this line


const Dashboard = (createproject ) => {
  const history = useHistory();  // Corrected this line

  const [activeSection, setActiveSection] = useState("Requests");
  const [componentToRender, setComponentToRender] = useState(<Requests/>);




  const handleSectionClick = (section) => {
    setActiveSection(section);

    switch (section) {
      case "Requests":
        setComponentToRender(<Requests/>);
        break;
      
      case "Annotators":
        setComponentToRender(<Annotators/>);
        break;
      case "Annotation Classes":
        setComponentToRender(<Annotationclasses/>);
        break;
     
      case "Logout":
        localStorage.clear();
        history.push("/");
        break;
      default:
        setComponentToRender(<div>Default Content</div>);
    }
  };

  const username = localStorage.getItem("username") || "User";
  const isSuperuser = localStorage.getItem("is_superuser");
  
  
  return (
    <div className="dashboard-container">
      {/* Left Panel */}
      <div className="left-panel">
        <div className="section logo-section" onClick={() => window.location.reload()}>
          <img
            src="./Annotafusion_Logo.png"
            alt="Annotafusion Logo"
            className="logo"
          />
        </div>
        <div style={{ backgroundColor: "darkgrey" }} className="section user-section">

          <p>
            <strong>{username}</strong> <br />
            <span>{isSuperuser=== "true" ? "[Admin Role]" : "[Annotator Role]"}</span>
          </p>
        </div>
        <div    className="section" onClick={() => handleSectionClick("Requests")}>
          Requests
        </div>
       

        {isSuperuser === "true" && (   <div
          className="section"
          onClick={() => handleSectionClick("Annotators")}
        >
          Annotators
        </div>)}
        <div
          className="section"
          onClick={() => handleSectionClick("Annotation Classes")}
        >
          Annotation Classes
        </div>
       
       
        
      
       
       
       
        <div className="section logout-section" onClick={() => handleSectionClick("Logout")}>
          LOG OUT
        </div>
      </div>

      {/* Right Panel */}
      <div  style={{
  width: "85%", // Corrected syntax: Use a comma, not a semicolon
  padding: "12px",
  backgroundColor: "#f8f8f8", // Use camelCase for property names like `backgroundColor`
  position: "relative", // Corrected syntax
  overflow : "auto"
}}  >
        <div className="dynamic-content">{componentToRender}</div>
      </div>
    </div>
  );
};





export default Dashboard;












