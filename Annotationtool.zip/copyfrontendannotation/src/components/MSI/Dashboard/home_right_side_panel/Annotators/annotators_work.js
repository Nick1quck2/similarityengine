
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ReactModal from 'react-modal';
import './annotators_work.css';

ReactModal.setAppElement('#root'); // Accessibility for screen readers

const AnnotatorsPage = () => {
  const [annotators, setAnnotators] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [selectedAnnotator, setSelectedAnnotator] = useState(null);
  const [newAnnotator, setNewAnnotator] = useState({ username: '', password: '', email: '', first_name: '', last_name: '' });
  const token = localStorage.getItem("access_token");

  // Fetch annotators
  useEffect(() => {
    axios.get('http://localhost:8000/users/', {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((response) => {
        setAnnotators(response.data.data);
      })
      .catch((error) => {
        console.error('Error fetching annotators:', error);
      });
  }, []);

  // Open/close modal
  const openModal = (annotator = null) => {
    setSelectedAnnotator(annotator);
    setNewAnnotator(
      annotator
        ? { ...annotator, password: '' } // Avoid showing password
        : { username: '', password: '', email: '', first_name: '', last_name: '' }
    );
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
  };

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewAnnotator((prev) => ({ ...prev, [name]: value }));
  };

  // Add or update annotator
  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedAnnotator) {
      axios.put(`http://localhost:8000/users/${selectedAnnotator.id}/`, newAnnotator, {
        headers: { Authorization: `Bearer ${token}` },
      })
        .then((response) => {
          alert('Annotator updated successfully!');
          setAnnotators((prev) =>
            prev.map((annotator) =>
              annotator.id === selectedAnnotator.id ? response.data.data : annotator
            )
          );
          closeModal();
        })
        .catch((error) => {
          alert('Error updating annotator');
          console.error('Error:', error);
        });
    } else {
      axios.post('http://localhost:8000/users/', newAnnotator, {
        headers: { Authorization: `Bearer ${token}` },
      })
        .then((response) => {
          alert('Annotator added successfully!');
          setAnnotators((prev) => [...prev, response.data.data]);
          closeModal();
        })
        .catch((error) => {
          alert('Error adding annotator');
          console.error('Error:', error);
        });
    }
  };

  // Delete annotator with confirmation
  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this annotator?")) {
      axios.delete(`http://localhost:8000/users/${id}/`, {
        headers: { Authorization: `Bearer ${token}` },
      })
        .then(() => {
          alert('Annotator deleted successfully!');
          setAnnotators((prev) => prev.filter((annotator) => annotator.id !== id));
        })
        .catch((error) => {
          alert('Error deleting annotator');
          console.error('Error:', error);
        });
    }
  };

  // Filter annotators by search
  const filteredAnnotators = annotators.filter((annotator) =>
    annotator.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="annotators-page">
      <header>
        <h1>Annotators</h1>
        <div className="controls">
          <button className="add-button" onClick={() => openModal()}>+ ADD Annotator</button>
          <input
            type="text"
            placeholder="Search by username"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
          />
        </div>
      </header>

      <div className="annotators-list">
        {filteredAnnotators.length > 0 ? (
          filteredAnnotators.map((annotator, index) => (
            <div key={annotator.id} className="annotator-card">
              <img src="./userlogo.png" alt="User logo" className="user-logo" />
              <div className="annotator-info">
                <strong>{index + 1}. {annotator.username}</strong>
                <p>{annotator.email}</p>
              </div>
              <div className="actions">
                <button  style={{backgroundColor : "blue"}} className="update-button" onClick={() => openModal(annotator)}>Update</button>
                <button  style={{backgroundColor : "red"}}  className="delete-button" onClick={() => handleDelete(annotator.id)}>Delete</button>
              </div>
            </div>
          ))
        ) : (
          <p>No annotators found</p>
        )}
      </div>

      <ReactModal isOpen={modalIsOpen} onRequestClose={closeModal} className="modal" overlayClassName="overlay">
        <div className="modal-header">
          <h2>{selectedAnnotator ? 'Update Annotator' : 'Add Annotator'}</h2>
        </div>
        <form onSubmit={handleSubmit} className="modal-form">
          <input
            type="text"
            name="username"
            placeholder="Username"
            value={newAnnotator.username}
            onChange={handleInputChange}
            required
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            value={newAnnotator.password}
            onChange={handleInputChange}
            required={!selectedAnnotator} // Required only for new annotators
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={newAnnotator.email}
            onChange={handleInputChange}
          />
          <input
            type="text"
            name="first_name"
            placeholder="First Name"
            value={newAnnotator.first_name}
            onChange={handleInputChange}
          />
          <input
            type="text"
            name="last_name"
            placeholder="Last Name"
            value={newAnnotator.last_name}
            onChange={handleInputChange}
          />
          <div className="modal-buttons">
            <button type="submit" className="submit-button">{selectedAnnotator ? 'Update' : 'Add'}</button>
            <button type="button" className="cancel-button" onClick={closeModal}>Cancel</button>
          </div>
        </form>
      </ReactModal>
    </div>
  );
};

export default AnnotatorsPage;
