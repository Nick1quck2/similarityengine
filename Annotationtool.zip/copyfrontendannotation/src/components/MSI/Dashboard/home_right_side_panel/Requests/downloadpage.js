import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { Pie } from "react-chartjs-2";
import "chart.js/auto";

const DownloadPage = (request_id, request_name) => {
  const [classesData, setClassesData] = useState([]);
  const [loading, setLoading] = useState(true);
  const token = localStorage.getItem("access_token");
  const [headerData, setHeaderData] = useState({ total_images: 0,  Total_annotated : 0 , Total_verified : 0 });

  useEffect(() => {
    const fetchHeaderData = async () => {
      try {
        const response = await axios.get(`http://localhost:8000/request/requestplatform/${request_id.request_id}`, {
           headers: { Authorization: `Bearer ${token}` } ,
        });
        const { total_images, Total_annotated  , Total_verified} = response.data.data;
        setHeaderData({ total_images, Total_annotated ,Total_verified});
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchHeaderData();
  }, [ ]); 




  useEffect(() => {
    const fetchClassesData = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8000/request/api/label-data-summary/${request_id.request_id}/`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        setClassesData(response.data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching classes data:", error);
      }
    };

    fetchClassesData();
  }, [request_id, token]);

  const handleDownload = async (type) => {
    try {
      const response = await axios.get(
        `http://localhost:8000/request/download/${request_id.request_id}/${type}/`,
        {
          responseType: "blob",
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute(
        "download",
        `${request_id.request_name}_${type}_annotations.zip`
      );
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error("Error downloading file:", error);
    }
  };

  const pieData = {
    labels: classesData.map((item) => item.class_name),
    datasets: [
      {
        data: classesData.map((item) => item.count),
        backgroundColor: classesData.map(
          (_, index) => `hsl(${(index * 30) % 360}, 70%, 60%)`
        ),
      },
    ],
  };

  return (
    <>
      <div style={{
        position: "fixed",
        top: "0",
        left: "16%",
        width: "100%",
        backgroundColor: "#f5f5f5", // Light background
        padding: "10px 20px",
        boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)", // Shadow for visual separation
        zIndex: "1000", // Ensure it stays on top
      }}>
      <div
        style={{
          backgroundColor: "white",
          padding: "15px",
          borderRadius: "8px",
          boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
          width: "30pxpx",
          height: "50px"
        }}
      >
        <h4>Total Images: {headerData.total_images} | Total Annotated : {headerData.Total_annotated}  |  Total Verified :  {headerData.Total_verified} </h4>
      </div>
    </div>


    <div style={{ padding: "20px" }}>
     <u><h1 style={{ color : "grey"}} >Download AnnotatedData for Training</h1></u>
      <br />
      {loading ? (
        <p>Loading data...</p>
      ) : (
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <div style={{ width: "40%" }}>
            <Pie data={pieData} />
          </div>
          <div style={{ width: "50%", overflowY: "auto", maxHeight: "400px", border: "1px solid #ddd", padding: "10px" }}>
            {classesData.map((item) => (
              <div key={item.class_name} style={{ margin: "5px 0" }}>
                <strong>{item.class_name}:</strong> {item.count}
              </div>
            ))}
          </div>
        </div>
      )}
      <div style={{ marginTop: "20px", display: "flex", justifyContent: "space-between" }}>
      <button
  onClick={() => handleDownload("full")}
  style={{
    backgroundColor: "#4CAF50",
    color: "white",
    padding: "10px 20px",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "16px",
    margin: "5px",
    transition: "background-color 0.3s",
  }}
  onMouseEnter={(e) => e.target.style.backgroundColor = "#45a049"}
  onMouseLeave={(e) => e.target.style.backgroundColor = "#4CAF50"}
>
  Download Full
</button>
<button
  onClick={() => handleDownload("verified")}
  style={{
    backgroundColor: "#008CBA",
    color: "white",
    padding: "10px 20px",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "16px",
    margin: "5px",
    transition: "background-color 0.3s",
  }}
  onMouseEnter={(e) => e.target.style.backgroundColor = "#007bb5"}
  onMouseLeave={(e) => e.target.style.backgroundColor = "#008CBA"}
>
  Download Verified
</button>

      </div>
    </div>
    </>
  );
};

export default DownloadPage;
