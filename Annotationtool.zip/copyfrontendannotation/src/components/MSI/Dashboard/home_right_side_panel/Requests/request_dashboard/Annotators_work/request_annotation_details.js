import React, { useState, useEffect } from "react";
import axios from "axios";
import { useHistory } from "react-router-dom";
import "./request_annotation_details.css"; // Custom CSS for styling

const TablePage = ({ linked,request_name, p_index, status }) => {
  const history = useHistory();
  const [collection2, setCollection2] = useState([]);
  const [filterDate, setFilterDate] = useState("");

  const username = localStorage.getItem("username");
  const token = localStorage.getItem("access_token");

  useEffect(() => {
    const fetchData = async () => {
      try {
        // First API Call to fetch collection1
        const response1 = await axios.get(
          `http://localhost:8000/request/assign-tasks/?linked=${linked}&username=${username}`,
          {  
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        const collection1 = response1.data.data;

        let collection2Temp = [];
        
        // Loop through collection1 and fetch data for collection2
        for (const item of collection1) {
          const response2 = await axios.get(
            `http://localhost:8000/request/task-users/?linked=${item.id}&username=${username}`,
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );
          collection2Temp = [...collection2Temp, ...response2.data.data];
        }

        // Store the fetched collection2 data
        setCollection2(collection2Temp);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [linked, username, token]);

  // Filter collection2 by date if filterDate is set
  const filteredData = filterDate
    ? collection2.filter((row) => row.created_at.startsWith(filterDate))
    : collection2;


  const navigationwork = (x_number,y_number)=>{
    history.push(`/annotation_work/${linked}/${request_name}/${x_number}/${y_number}/${p_index}/${status}`)


  }  
  return (
    <div className="table-container">
      <h1 className="page-title">Task Annotation Table</h1>

      <div className="filter-box">
        <label htmlFor="filter-date">Filter by Date:</label>
        <input
          type="date"
          id="filter-date"
          value={filterDate}
          onChange={(e) => setFilterDate(e.target.value)}
        />
      </div>

      <div className="table-wrapper">
        <table className="data-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>X_number</th>
              <th>Y_number</th>
              <th>Total Images</th>
              <th>Total Annotated</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredData.map((row, index) => (
              <tr key={index} className="table-row">
                <td>{row.created_at}</td>
                <td>{row.user_x_number}</td>
                <td>{row.user_y_number}</td>
                <td>{row.total_images}</td>
                <td>{row.total_annotated}</td>
                <td>
                <button 
  onClick={() => navigationwork(row.user_x_number, row.user_y_number)} 
  className="action-button"
>
  Start Labeling
</button>                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TablePage;
