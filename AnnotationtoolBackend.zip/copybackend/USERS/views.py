from django.shortcuts import render

# Create your views here.
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework import status,viewsets
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.contrib.auth import authenticate
from .serializers import UserSerializer
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.decorators import action


@api_view(['POST'])
@permission_classes([AllowAny])  # Allow access without authentication for login
def login(request):
    username = request.data.get('username')
    password = request.data.get('password')

    if not username or not password:
        return Response({'error': 'Username and password are required.'}, status=status.HTTP_400_BAD_REQUEST)

    user = authenticate(request, username=username, password=password)

    if user is not None:
        if user.is_active:
            refresh = RefreshToken.for_user(user)
            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
                'username': user.username,
                'is_superuser': user.is_superuser,  # Include is_superuser in the response
            }, status=status.HTTP_200_OK)
        else:
            return Response({'error': 'User account is disabled.'}, status=status.HTTP_403_FORBIDDEN)
    else:
        return Response({'error': 'Invalid username or password.'}, status=status.HTTP_401_UNAUTHORIZED)






class UserViewSet(viewsets.ModelViewSet):
    """
    API for managing non-superuser users.
    """
    serializer_class = UserSerializer

    def get_queryset(self):
        # Filter users who are not superusers
        return User.objects.filter(is_superuser=False)

    def list(self, request, *args, **kwargs):
        """
        List all non-superuser users.
        """
        queryset = self.get_queryset()
        serializer = self.get_serializer(queryset, many=True)
        return Response({
            "status": "success",
            "message": "User list retrieved successfully.",
            "data": serializer.data,
        }, status=status.HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        """
        Create a new non-superuser user.
        """
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({
            "status": "success",
            "message": "User created successfully.",
            "data": serializer.data,
        }, status=status.HTTP_201_CREATED)

    def update(self, request, *args, **kwargs):
        """
        Update an existing non-superuser user.
        """
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({
            "status": "success",
            "message": "User updated successfully.",
            "data": serializer.data,
        }, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        """
        Delete a non-superuser user.
        """
        instance = self.get_object()
        instance.delete()
        return Response({
            "status": "success",
            "message": "User deleted successfully.",
            "data": None,
        }, status=status.HTTP_204_NO_CONTENT)
