from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.views import APIView
from rest_framework.viewsets import ModelViewSet
from rest_framework.response import Response
from rest_framework import status,viewsets
from django.contrib.auth.models import User
from django.http import JsonResponse, HttpResponse
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
import json
from django.db import models  # Import models for ORM functionalities

import zipfile
from io import BytesIO
from .models import (RequestPlatform,Annotationclasses, Assign_Annotation_Tasks,
    Assign_Verification_Tasks,
    Task_Annotation_User,
    Task_Verification_User)

from django.shortcuts import get_object_or_404

from .serializers import RequestPlatformSerializer ,AnnotationClassesSerializer,AssignAnnotationTasksSerializer,TaskAnnotationUserSerializer,LabelationSerializer, LabelDataSerializer
import os
from django.conf import settings
from django.http import FileResponse
from .models import RequestPlatform
from .serializers import AssignVerificationTasksSerializer,TaskVerificationUserSerializer
class RequestPlatformView(APIView):
    def get_image_count(self, request_name):
        """Helper method to count images in the 'images' subfolder."""
        images_path = os.path.join(settings.MEDIA_ROOT, request_name, 'images')
        if os.path.exists(images_path):
            return len([
                f for f in os.listdir(images_path)
                if os.path.isfile(os.path.join(images_path, f))
            ])
        return 0

    def get(self, request, pk=None):
        if pk:
            try:
                request_platform = RequestPlatform.objects.get(pk=pk)
                # Dynamically update total_images before responding
                request_platform.total_images = self.get_image_count(request_platform.request_name)
                request_platform.save()
                serializer = RequestPlatformSerializer(request_platform)
                return Response({
                    "status": "success",
                    "message": "Request platform retrieved successfully.",
                    "data": serializer.data
                }, status=status.HTTP_200_OK)
            except RequestPlatform.DoesNotExist:
                return Response({
                    "status": "error",
                    "message": "Request platform not found.",
                    "data": None
                }, status=status.HTTP_404_NOT_FOUND)
        else:
            request_platforms = RequestPlatform.objects.all()
            for platform in request_platforms:
                # Update total_images for all platforms dynamically
                platform.total_images = self.get_image_count(platform.request_name)
                platform.save()
            serializer = RequestPlatformSerializer(request_platforms, many=True)
            return Response({
                "status": "success",
                "message": "Request platforms retrieved successfully.",
                "data": serializer.data
            }, status=status.HTTP_200_OK)

    def post(self, request):
        serializer = RequestPlatformSerializer(data=request.data)
        if serializer.is_valid():
            request_platform = serializer.save()
            # Create necessary folders
            base_path = os.path.join(settings.MEDIA_ROOT, request_platform.request_name)
            os.makedirs(os.path.join(base_path, 'images'), exist_ok=True)
            os.makedirs(os.path.join(base_path, 'labels'), exist_ok=True)

            return Response({
                "status": "success",
                "message": "Request platform created successfully.",
                "data": serializer.data
            }, status=status.HTTP_201_CREATED)
        return Response({
            "status": "error",
            "message": "Validation error.",
            "data": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        try:
            request_platform = RequestPlatform.objects.get(pk=pk)
            serializer = RequestPlatformSerializer(request_platform, data=request.data, partial=True)
            if serializer.is_valid():
                request_platform = serializer.save()
                # Update total_images dynamically after update
                request_platform.total_images = self.get_image_count(request_platform.request_name)
                request_platform.save()
                return Response({
                    "status": "success",
                    "message": "Request platform updated successfully.",
                    "data": serializer.data
                }, status=status.HTTP_200_OK)
            return Response({
                "status": "error",
                "message": "Validation error.",
                "data": serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)
        except RequestPlatform.DoesNotExist:
            return Response({
                "status": "error",
                "message": "Request platform not found.",
                "data": None
            }, status=status.HTTP_404_NOT_FOUND)

    def delete(self, request, pk):
        try:
            request_platform = RequestPlatform.objects.get(pk=pk)
            # Remove associated folders
            base_path = os.path.join(settings.MEDIA_ROOT, request_platform.request_name)
            if os.path.exists(base_path):
                import shutil
                shutil.rmtree(base_path)
            request_platform.delete()
            return Response({
                "status": "success",
                "message": "Request platform deleted successfully.",
                "data": None
            }, status=status.HTTP_200_OK)
        except RequestPlatform.DoesNotExist:
            return Response({
                "status": "error",
                "message": "Request platform not found.",
                "data": None
            }, status=status.HTTP_404_NOT_FOUND)       
###annotationclass



class AnnotationClassesViewSet(ModelViewSet):
    queryset = Annotationclasses.objects.all()
    serializer_class = AnnotationClassesSerializer

    def list(self, request):
        annotation_classes = Annotationclasses.objects.all()
        serializer = AnnotationClassesSerializer(annotation_classes, many=True)
        return Response({
            "status": "success",
            "message": "Annotation classes fetched successfully",
            "data": serializer.data
        })

    def create(self, request):
        serializer = AnnotationClassesSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({
                "status": "success",
                "message": "Annotation class created successfully",
                "data": serializer.data
            }, status=status.HTTP_201_CREATED)
        return Response({
            "status": "error",
            "message": "Failed to create annotation class",
            "data": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, pk=None):
        annotation_class = Annotationclasses.objects.get(pk=pk)
        serializer = AnnotationClassesSerializer(annotation_class, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({
                "status": "success",
                "message": "Annotation class updated successfully",
                "data": serializer.data
            })
        return Response({
            "status": "error",
            "message": "Failed to update annotation class",
            "data": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, pk=None):
        annotation_class = Annotationclasses.objects.get(pk=pk)
        annotation_class.delete()
        return Response({
            "status": "success",
            "message": "Annotation class deleted successfully",
            "data": {}
        }, status=status.HTTP_204_NO_CONTENT)



###logic of image,labels creation of requestname folders 
class ImagesAPIView(APIView):
    """CRUD operations for the 'images' subfolder of a RequestPlatform."""
    def get(self, request, request_name):
        """List all images in the 'images' subfolder without pagination."""
        try:
            x_number = request.GET.get('x_number')
            y_number = request.GET.get('y_number')

            # Validate x_number and y_number
            if x_number is not None and y_number is not None:
                try:
                    x_number = int(x_number)
                    y_number = int(y_number)
                    if x_number < 0 or y_number < 0 or x_number > y_number:
                        raise ValueError
                except ValueError:
                    return Response({
                        'data': 'error',
                        'message': 'x_number and y_number must be valid non-negative integers with x_number <= y_number'
                    }, status=status.HTTP_400_BAD_REQUEST)

            # Get the base path for the images folder
            request_obj = RequestPlatform.objects.get(request_name=request_name)
            images_path = os.path.join(settings.MEDIA_ROOT, request_name, 'images')

            if not os.path.isdir(images_path):
                return Response({
                    'status': 'error',
                    'message': 'Folder does not exist'
                }, status=status.HTTP_404_NOT_FOUND)

            # List all files in the images folder
            files = os.listdir(images_path)
            images = [
                {'filename': f, 'url': f"{settings.MEDIA_URL}{request_name}/images/{f}"}
                for f in files if os.path.isfile(os.path.join(images_path, f))
            ]

            # Filter images by range if x_number and y_number are provided
            if x_number is not None and y_number is not None:
                images = images[x_number - 1:y_number]

            return Response({
                'status': 'success',
                'message': 'Images retrieved successfully',
                'data': images,
            }, status=status.HTTP_200_OK)

        except RequestPlatform.DoesNotExist:
            return Response({
                'data': 'error',
                'message': 'RequestPlatform not found'
            }, status=status.HTTP_404_NOT_FOUND)     
        
    def post(self, request, request_name):
        """Upload a new image to the 'images' subfolder."""
        try:
            request_obj = RequestPlatform.objects.get(request_name=request_name)
            images_path = os.path.join(settings.MEDIA_ROOT, request_name, 'images')

            if 'file' not in request.FILES:
                return Response({'status': 'error', 'message': 'No file provided'}, status=status.HTTP_400_BAD_REQUEST)

            file = request.FILES['file']
            file_path = os.path.join(images_path, file.name)

            with open(file_path, 'wb') as f:
                for chunk in file.chunks():
                    f.write(chunk)

            return Response({'status': 'success', 'message': 'Image uploaded successfully'}, status=status.HTTP_201_CREATED)
        except RequestPlatform.DoesNotExist:
            return Response({'status': 'error', 'message': 'RequestPlatform not found'}, status=status.HTTP_404_NOT_FOUND)

    def delete(self, request, request_name, filename):
        """Delete an image from the 'images' subfolder."""
        try:
            request_obj = RequestPlatform.objects.get(request_name=request_name)
            file_path = os.path.join(settings.MEDIA_ROOT, request_name, 'images', filename)

            if os.path.exists(file_path):
                os.remove(file_path)
                return Response({'status': 'success', 'message': 'Image deleted successfully'}, status=status.HTTP_200_OK)
            return Response({'status': 'error', 'message': 'File not found'}, status=status.HTTP_404_NOT_FOUND)
        except RequestPlatform.DoesNotExist:
            return Response({'status': 'error', 'message': 'RequestPlatform not found'}, status=status.HTTP_404_NOT_FOUND)
        


class AssignAnnotationTasksViewSet(viewsets.ViewSet):
    def list(self, request):
        linked = request.GET.get("linked")
        username = request.GET.get("username")
        if linked:
            
            tasks = Assign_Annotation_Tasks.objects.filter(linked = linked)
            if username:
                tasks = tasks.filter(all_annotators__username=username)
        else:
            tasks = Assign_Annotation_Tasks.objects.all()
        serializer = AssignAnnotationTasksSerializer(tasks, many=True)
        return Response({'status': 'success', 'message': 'Tasks retrieved successfully', 'data': serializer.data}, status=status.HTTP_200_OK)

    def create(self, request):
        serializer = AssignAnnotationTasksSerializer(data=request.data)
        
        if serializer.is_valid():
            serializer.save()
            return Response({'status': 'success', 'message': 'Task created successfully', 'data': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'status': 'error', 'message': 'Failed to create task', 'data': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

    def retrieve(self, request, pk=None):
        try:
            task = Assign_Annotation_Tasks.objects.get(pk=pk)
            serializer = AssignAnnotationTasksSerializer(task)
            return Response({'status': 'success', 'message': 'Task retrieved successfully', 'data': serializer.data}, status=status.HTTP_200_OK)
        except Assign_Annotation_Tasks.DoesNotExist:
            return Response({'status': 'error', 'message': 'Task not found'}, status=status.HTTP_404_NOT_FOUND)

    def update(self, request, pk=None):
        try:
            task = Assign_Annotation_Tasks.objects.get(pk=pk)
            serializer = AssignAnnotationTasksSerializer(task, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({'status': 'success', 'message': 'Task updated successfully', 'data': serializer.data}, status=status.HTTP_200_OK)
            return Response({'status': 'error', 'message': 'Failed to update task', 'data': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except Assign_Annotation_Tasks.DoesNotExist:
            return Response({'status': 'error', 'message': 'Task not found'}, status=status.HTTP_404_NOT_FOUND)

    def destroy(self, request, pk=None):
        try:
            task = Assign_Annotation_Tasks.objects.get(pk=pk)
            task.delete()
            return Response({'status': 'success', 'message': 'Task deleted successfully'}, status=status.HTTP_200_OK)
        except Assign_Annotation_Tasks.DoesNotExist:
            return Response({'status': 'error', 'message': 'Task not found'}, status=status.HTTP_404_NOT_FOUND)
        



class TaskAnnotationUserViewSet(viewsets.ViewSet):
    def list(self, request):
        linked = request.GET.get("linked")
        username = request.GET.get("username")
        
        if linked:

            users = Task_Annotation_User.objects.filter(linked = linked)
            if username:
                # Filter by the `username` of the related `User`
                users = users.filter(user__username=username)

        else:
            users = Task_Annotation_User.objects.all()

        serializer = TaskAnnotationUserSerializer(users, many=True)
        return Response({'status': 'success', 'message': 'Users retrieved successfully', 'data': serializer.data}, status=status.HTTP_200_OK)

    def create(self, request):
        serializer = TaskAnnotationUserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'status': 'success', 'message': 'User task created successfully', 'data': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'status': 'error', 'message': 'Failed to create user task', 'data': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

    def retrieve(self, request, pk=None):
        try:
            user_task = Task_Annotation_User.objects.get(pk=pk)
            serializer = TaskAnnotationUserSerializer(user_task)
            return Response({'status': 'success', 'message': 'User task retrieved successfully', 'data': serializer.data}, status=status.HTTP_200_OK)
        except Task_Annotation_User.DoesNotExist:
            return Response({'status': 'error', 'message': 'User task not found'}, status=status.HTTP_404_NOT_FOUND)

    def update(self, request, pk=None):
        try:
            user_task = Task_Annotation_User.objects.get(pk=pk)
            serializer = TaskAnnotationUserSerializer(user_task, data=request.data)
            if serializer.is_valid():
                serializer.save()
            
                return Response({'status': 'success', 'message': 'User task updated successfully', 'data': serializer.data}, status=status.HTTP_200_OK)
            return Response({'status': 'error', 'message': 'Failed to update user task', 'data': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except Task_Annotation_User.DoesNotExist:
            return Response({'status': 'error', 'message': 'User task not found'}, status=status.HTTP_404_NOT_FOUND)

    def destroy(self, request, pk=None):
        try:
            user_task = Task_Annotation_User.objects.get(pk=pk)
            user_task.delete()
            return Response({'status': 'success', 'message': 'User task deleted successfully'}, status=status.HTTP_200_OK)
        except Task_Annotation_User.DoesNotExist:
            return Response({'status': 'error', 'message': 'User task not found'}, status=status.HTTP_404_NOT_FOUND)








class AssignVerificationTasksViewSet(viewsets.ViewSet):
    def list(self, request):
        linked = request.GET.get("linked")
        username = request.GET.get("username")
        if linked:
            tasks = Assign_Verification_Tasks.objects.filter(linked= linked)
            if username:
                tasks = tasks.filter(all_verifiers__username=username)
        else:
            tasks = Assign_Verification_Tasks.objects.all()
        serializer = AssignVerificationTasksSerializer(tasks, many=True)
        return Response({'status': 'success', 'message': 'Tasks retrieved successfully', 'data': serializer.data}, status=status.HTTP_200_OK)

    def create(self, request):
        serializer = AssignVerificationTasksSerializer(data=request.data)
        print(serializer,'-----------')
        if serializer.is_valid():
            serializer.save()
            return Response({'status': 'success', 'message': 'Task created successfully', 'data': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'status': 'error', 'message': 'Failed to create task', 'data': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

    def retrieve(self, request, pk=None):
        try:
            task = Assign_Verification_Tasks.objects.get(pk=pk)
            serializer =AssignVerificationTasksSerializer(task)
            return Response({'status': 'success', 'message': 'Task retrieved successfully', 'data': serializer.data}, status=status.HTTP_200_OK)
        except Assign_Verification_Tasks.DoesNotExist:
            return Response({'status': 'error', 'message': 'Task not found'}, status=status.HTTP_404_NOT_FOUND)

    def update(self, request, pk=None):
        try:
            task = Assign_Verification_Tasks.objects.get(pk=pk)
            serializer = AssignVerificationTasksSerializer(task, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({'status': 'success', 'message': 'Task updated successfully', 'data': serializer.data}, status=status.HTTP_200_OK)
            return Response({'status': 'error', 'message': 'Failed to update task', 'data': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except Assign_Verification_Tasks.DoesNotExist:
            return Response({'status': 'error', 'message': 'Task not found'}, status=status.HTTP_404_NOT_FOUND)

    def destroy(self, request, pk=None):
        try:
            task = Assign_Verification_Tasks.objects.get(pk=pk)
            task.delete()
            return Response({'status': 'success', 'message': 'Task deleted successfully'}, status=status.HTTP_200_OK)
        except Assign_Verification_Tasks.DoesNotExist:
            return Response({'status': 'error', 'message': 'Task not found'}, status=status.HTTP_404_NOT_FOUND)
        




class TaskVerificationUserViewSet(viewsets.ViewSet):
    def list(self, request):
        linked = request.GET.get("linked")
        username = request.GET.get("username")
        if linked:
            users =  Task_Verification_User.objects.filter(linked = linked)
            if username:
                # Filter by the `username` of the related `User`
                users = users.filter(user__username=username)
        else:
            users =  Task_Verification_User.objects.all()
        serializer = TaskVerificationUserSerializer(users, many=True)
        return Response({'status': 'success', 'message': 'Users retrieved successfully', 'data': serializer.data}, status=status.HTTP_200_OK)

    def create(self, request):
        serializer = TaskVerificationUserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'status': 'success', 'message': 'User task created successfully', 'data': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'status': 'error', 'message': 'Failed to create user task', 'data': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

    def retrieve(self, request, pk=None):
        try:
            user_task =  Task_Verification_User.objects.get(pk=pk)
            serializer = TaskVerificationUserSerializer(user_task)
            return Response({'status': 'success', 'message': 'User task retrieved successfully', 'data': serializer.data}, status=status.HTTP_200_OK)
        except  Task_Verification_User.DoesNotExist:
            return Response({'status': 'error', 'message': 'User task not found'}, status=status.HTTP_404_NOT_FOUND)

    def update(self, request, pk=None):
        try:
            user_task =  Task_Verification_User.objects.get(pk=pk)
            serializer = TaskVerificationUserSerializer(user_task, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({'status': 'success', 'message': 'User task updated successfully', 'data': serializer.data}, status=status.HTTP_200_OK)
            return Response({'status': 'error', 'message': 'Failed to update user task', 'data': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except  Task_Verification_User.DoesNotExist:
            return Response({'status': 'error', 'message': 'User task not found'}, status=status.HTTP_404_NOT_FOUND)

    def destroy(self, request, pk=None):
        try:
            user_task =  Task_Verification_User.objects.get(pk=pk)
            user_task.delete()
            return Response({'status': 'success', 'message': 'User task deleted successfully'}, status=status.HTTP_200_OK)
        except  Task_Verification_User.DoesNotExist:
            return Response({'status': 'error', 'message': 'User task not found'}, status=status.HTTP_404_NOT_FOUND)


from .models import Labelation, Label_data


class LabelationAPIView(APIView):
    def get(self, request, pk=None):
        linked = request.GET.get("linked")
        x_number = request.GET.get("x_number", None)
        y_number = request.GET.get("y_number", None)

        try:
            if pk:
                # Fetch a specific Labelation by primary key
                if linked:
                    labelation = Labelation.objects.get(pk=pk, linked=linked)
                else:
                    labelation = Labelation.objects.get(pk=pk)
                serializer = LabelationSerializer(labelation)
                return Response({'status': 'success', 'message': 'Labelation retrieved', 'data': serializer.data}, status=status.HTTP_200_OK)
            else:
                # Fetch a range of Labelations
                labelations = Labelation.objects.all()

                if linked:
                    labelations = labelations.filter(linked=linked)
                
                if x_number is not None and y_number is not None:
                    try:
                        x_number = int(x_number)
                        y_number = int(y_number)
                        labelations = labelations.filter(Image_number__gte=x_number, Image_number__lte=y_number)
                    except ValueError:
                        return Response({'status': 'error', 'message': 'x_number and y_number must be integers'}, status=status.HTTP_400_BAD_REQUEST)

                serializer = LabelationSerializer(labelations, many=True)
                return Response({'status': 'success', 'message': 'Labelations retrieved', 'data': serializer.data}, status=status.HTTP_200_OK)

        except Labelation.DoesNotExist:
            return Response({'status': 'error', 'message': 'Labelation not found'}, status=status.HTTP_404_NOT_FOUND)


    def post(self, request):
        image_number = request.GET.get('Image_number')
        linked_id = request.GET.get('linked')  # Ensure linked is part of the incoming request

        # Validate that Image_number and linked are provided
        if image_number is None or linked_id is None:
            return Response(
                {'status': 'error', 'message': 'Image_number and linked fields are required.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Check if a Labelation with the same Image_number and linked ID exists
        existing_labelation = Labelation.objects.filter(Image_number=image_number, linked_id=linked_id).first()
        annotated_by_user = False   
        # If an existing Labelation is found, delete it and preserve the 'annotated_by' if it exists
        if existing_labelation:
            annotated_by_user = existing_labelation.annotated_by  # Preserve annotated_by user if it exists
            annotated_date = existing_labelation.date_annotated
            


            existing_labelation.delete()
            
            print(f"Deleted existing Labelation with Image_number {image_number} for linked ID {linked_id}")

        # Create a new Labelation with the provided data
        serializer = LabelationSerializer(data=request.data)
        if serializer.is_valid():
            new_labelation = serializer.save()
            
            
            # If 'annotated_by' was preserved, apply it to the new Labelation
            if annotated_by_user and    not(new_labelation.annotated_by) :
                new_labelation.annotated_by = annotated_by_user
                new_labelation.date_annotated = annotated_date

                new_labelation.save()  # Save the Labelation again after updating 'annotated_by'

            
            
            return Response(
                {'status': 'success', 'message': 'Labelation created', 'data': serializer.data},
                status=status.HTTP_201_CREATED
            )

        return Response(
            {'status': 'error', 'message': 'Invalid data', 'data': serializer.errors},
            status=status.HTTP_400_BAD_REQUEST
        )

    
    def put(self, request, pk):
        try:
            labelation = Labelation.objects.get(pk=pk)
            serializer = LabelationSerializer(labelation, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response({'status': 'success', 'message': 'Labelation updated', 'data': serializer.data}, status=status.HTTP_200_OK)
            return Response({'status': 'error', 'message': 'Invalid data', 'data': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except Labelation.DoesNotExist:
            return Response({'status': 'error', 'message': 'Labelation not found'}, status=status.HTTP_404_NOT_FOUND)

    def delete(self, request, pk):
        try:
            labelation = Labelation.objects.get(pk=pk)
            labelation.delete()
            return Response({'status': 'success', 'message': 'Labelation deleted'}, status=status.HTTP_204_NO_CONTENT)
        except Labelation.DoesNotExist:
            return Response({'status': 'error', 'message': 'Labelation not found'}, status=status.HTTP_404_NOT_FOUND)

# API View for Label_data
class LabelDataAPIView(APIView):
    
    def get(self, request, pk=None):
        linked = request.GET.get("linked")
        if pk:
            try:
                if linked :
                    label_data = Label_data.objects.get(pk=pk, linked=linked)
                else:
                    label_data = Label_data.objects.get(pk=pk)

                serializer = LabelDataSerializer(label_data)
                return Response({'status': 'success', 'message': 'Label data retrieved', 'data': serializer.data}, status=status.HTTP_200_OK)
            except Label_data.DoesNotExist:
                return Response({'status': 'error', 'message': 'Label data not found'}, status=status.HTTP_404_NOT_FOUND)
        else:
            if linked :
                label_data_list = Label_data.objects.filter(linked=linked)
            else:
                label_data_list = Label_data.objects.all()

            serializer = LabelDataSerializer(label_data_list, many=True)
            return Response({'status': 'success', 'message': 'Label data retrieved', 'data': serializer.data}, status=status.HTTP_200_OK)

    def post(self, request):
        serializer = LabelDataSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'status': 'success', 'message': 'Label data created', 'data': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'status': 'error', 'message': 'Invalid data', 'data': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        try:
            label_data = Label_data.objects.get(pk=pk)
            serializer = LabelDataSerializer(label_data, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response({'status': 'success', 'message': 'Label data updated', 'data': serializer.data}, status=status.HTTP_200_OK)
            return Response({'status': 'error', 'message': 'Invalid data', 'data': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except Label_data.DoesNotExist:
            return Response({'status': 'error', 'message': 'Label data not found'}, status=status.HTTP_404_NOT_FOUND)

    def delete(self, request, pk):
        try:
            label_data = Label_data.objects.get(pk=pk)
            label_data.delete()
            return Response({'status': 'success', 'message': 'Label data deleted'}, status=status.HTTP_204_NO_CONTENT)
        except Label_data.DoesNotExist:
            return Response({'status': 'error', 'message': 'Label data not found'}, status=status.HTTP_404_NOT_FOUND)
        

def download_annotations(request, request_id, download_type):
    try:
        request_platform = RequestPlatform.objects.get(id=request_id)
        labelations = Labelation.objects.filter(linked=request_platform)
        
        # Filter based on download type
        if download_type == "full":
            labelations = labelations.filter(annotated_by__isnull=False)
        elif download_type == "verified":
            labelations = labelations.filter(verified_by__isnull=False)
        else:
            return JsonResponse({"error": "Invalid download type."}, status=400)

        data = []
        for labelation in labelations:
            label_data = Label_data.objects.filter(linked=labelation)
            label_row = {
                "Request_name": request_platform.request_name,
                "Request_id": request_platform.id,
                "Image_name": labelation.Image_name,
                "Date_annotated": labelation.date_annotated.strftime('%Y-%m-%d') if labelation.date_annotated else None,
                "Date_verified": labelation.date_verified.strftime('%Y-%m-%d') if labelation.date_verified else None,
                "annotated_by": labelation.annotated_by.username if labelation.annotated_by else None,
                "verified_by": labelation.verified_by.username if labelation.verified_by else None,
                "coordinates": []
            }
            for item in label_data:
                label_row["coordinates"].append({
                    "Class_name": item.class_name.name,
                    "x": item.x,
                    "y": item.y,
                    "w": item.w,
                    "h": item.h,
                })
            data.append(label_row)
        



        # Convert to JSON and prepare a zip file
        json_data = json.dumps(data, indent=4)
        file_name = f"{request_platform.request_name}_{download_type}_annotations.json"
        in_memory = BytesIO()
        with zipfile.ZipFile(in_memory, "w") as zf:
            zf.writestr(file_name, json_data)
        in_memory.seek(0)

        response = HttpResponse(in_memory, content_type="application/zip")
        response["Content-Disposition"] = f"attachment; filename={file_name}.zip"
        return response

    except RequestPlatform.DoesNotExist:
        return JsonResponse({"error": "RequestPlatform not found."}, status=404)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


def label_data_summary(request, request_id):
    try:
        request_platform = RequestPlatform.objects.get(id=request_id)
        labels = Label_data.objects.filter(linked__linked=request_platform)
        class_summary = labels.values("class_name__name").annotate(count=models.Count("class_name"))
        response = [{"class_name": item["class_name__name"], "count": item["count"]} for item in class_summary]
        return JsonResponse(response, safe=False)
    except RequestPlatform.DoesNotExist:
        return JsonResponse({"error": "RequestPlatform not found."}, status=404)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)   
    

####
