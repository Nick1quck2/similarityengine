import React from "react";
import ReactImageAnnotate from "react-image-annotate";

const handleExit = (output) => {
  console.log(output);
};

const App12 = () => {
  return (
    <ReactImageAnnotate
      labelImages
      taskDescription = "META Annotator"
      regionClsList={["Alpha", "Beta", "Charlie", "Delta"]}
      regionTagList={["tag1", "tag2", "tag3"]}
      images={[
        {
          src: "https://cdn.britannica.com/37/154237-050-A76A506D/blue-peafowl-tail-Indian-peacock-courtship-displays.jpg",
          name: "Image 1",
         
        },
      ]}

      
      // Logs the output when the user exits the annotation tool
      onExit={handleExit}
    />
  );
};

export default App12;
