import React, { useState, useEffect } from "react";
import { useParams, useHistory } from "react-router-dom";
import axios from "axios";
import ReactImageAnnotate from "react-image-annotate";
const AnnotationMakingPage = () => {
  const { request_id, request_name, x_number, y_number, p_index, status } =
    useParams();
  const history = useHistory();
  const token = localStorage.getItem("access_token");
  const user = localStorage.getItem("username");

  const [classes, setClasses] = useState([]);
  const [tags, setTags] = useState([]);

  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(true);

  const [selectedImageIndex, setSelectedImageIndex] = useState(0); // Track current image index
  const [currentImageannotated , setcurrentImageannotated] = useState(false);


const getimagestatus = async (current_image_number) => {
  const response = await axios.get(
    `http://localhost:8000/request/track-stats/linked_id=${request_id}&x_number=${current_image_number}`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
  if (response.data.data.total_annotated==1){
    setcurrentImageannotated(true);

  }
  else{
    setcurrentImageannotated(false);

  }
  

};


  useEffect(() => {

     


  }, [selectedImageIndex,]);


  useEffect(() => {
    const fetchClasses = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8000/request/requestplatform/${request_id}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },             
          }
        );
        setClasses(response.data.data.classes || []);
        setTags(response.data.data.tags || []);
      } catch (error) {
        console.error("Error fetching classes:", error);
      }
    };

   

    const fetchImages = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8000/request/images/${request_name}?x_number=${x_number}&y_number=${y_number}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        const imageList = response.data.data.map((image) => ({
          src: `http://localhost:8000/${image.url}`,
          name: image.filename,
        }));
        setImages(imageList);
      } catch (error) {
        console.error("Error fetching images:", error);
      }
    };

    const fetchData = async () => {
      setLoading(true);
      await fetchClasses();
      await fetchImages();
      setLoading(false);
    };

    fetchData();
  }, [request_id, request_name, x_number, y_number, token]);

  const handleSaveAnnotations = async (output) => {
    try {
      const xNum = parseInt(x_number, 10);
      const yNum = parseInt(y_number, 10);
  
      // Calculate the current image number based on x_number and selectedImageIndex
      const currentImageNumber = xNum + selectedImageIndex;
      const currentImage = output.images[selectedImageIndex];
      console.log(currentImage);
  
      if (!currentImage || !currentImage.regions || currentImage.regions.length === 0) {
        console.log("No annotations to save for this image.");
        
        return;
      }
  
      // Extract the annotations for the current image
      const annotations = {
        Image_name: currentImage.name,
        Image_number: currentImageNumber,
        regions: currentImage.regions.map((region) => {
          const isBox = region.type == "box";
          const className = region.cls || classes[0]; // Fallback to first class if `cls` is missing
  
          return {
            id: region.id,
            class_name: className,
            color: region.color,
            type: region.type,
            ...(isBox
              ? {
                  // Box-specific properties
                  x: region.x,
                  y: region.y,
                  w: region.w,
                  h: region.h,
                }
              : {
                  // Polygon-specific properties
                  points: region.points,
                }),
            tags: region.tags || [] // Include tags if available
          };
        }),
      };
  
      // Proceed with saving annotations for the current image
      const date_annotated = new Date().toISOString().split("T")[0];
  
      // Save Labelation data
      const labelationResponse = await axios.post(
        `http://localhost:8000/request/labelation/?linked=${request_id}&Image_number=${annotations.Image_number}`,
        {
          linked: request_id,
          Image_name: annotations.Image_name,
          Image_number: annotations.Image_number,
          annotated_by: user,
          date_annotated: date_annotated,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
  
      const labelationId = labelationResponse.data.data.id;
  
      for (const region of annotations.regions) {
        // Save Label Data
        await axios.post(
          `http://localhost:8000/request/label-data/`,
          {
            linked: labelationId,
            class_name: region.class_name,
            color: region.color,
            region_id: region.id,
            tags: region.tags,
            type: region.type,
            ...(region.type === "box"
              ? {
                  // Box-specific payload
                  x: region.x,
                  y: region.y,
                  w: region.w,
                  h: region.h,
                }
              : {
                  // Polygon-specific payload
                  points: region.points, // Array of {x, y} pairs
                }),
          },
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
      }
    } catch (error) {
      console.error("Error saving annotations:", error);
    }
  };
  
 const handlePrevious  = () => {
  if (selectedImageIndex > 0) {
    setSelectedImageIndex(selectedImageIndex - 1);
  }
  else{
    alert("No previous image");

  }

 };


  const handleNext = async (output) => {
    await handleSaveAnnotations(output);

    // Move to the next image if available
    setSelectedImageIndex((prevIndex) => {
      if (prevIndex < images.length - 1) {
        return prevIndex + 1;
      } else {
        alert("You have reached the last image!");
        return prevIndex;
      }
    });
  };

  const handleExit = () => {
    alert("Annotation completed");
    history.push(

      `/request_dashboard/${request_id}/${request_name}/${p_index}/${status}/annotation-tasks`
    );
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  

  return (
    <>
      <ReactImageAnnotate
        labelImages
        regionClsList={classes}
        images={images}
        regionTagList={tags}

        selectedImage={selectedImageIndex} // Pass the selected image index
        onNextImage={handleNext} // Save and move to the next image
        onPrevImage = {handlePrevious}
        onExit={handleExit} // Navigate without saving
      />
    </>
  );
};

export default AnnotationMakingPage;


