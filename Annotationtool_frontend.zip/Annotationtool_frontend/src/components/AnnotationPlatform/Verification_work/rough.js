import React, { useState, useEffect } from "react";
import { useParams, useHistory } from "react-router-dom";
import axios from "axios";
import ReactImageAnnotate from "react-image-annotate";

const VerificationMakingPage = () => {
  const { request_id, request_name, x_number, y_number, p_index, status , come  } = useParams();
  const history = useHistory();
  const token = localStorage.getItem("access_token");
  const user = localStorage.getItem("username");
  console.log(come,'------------------come');
  const [tags, setTags] = useState([]);

  const [classes, setClasses] = useState([]);
  const [images, setImages] = useState([]);
  const [originalImages, setOriginalImages] = useState([]); // To store the original state
  const [loading, setLoading] = useState(true);
    const [selectedImageIndex, setSelectedImageIndex] = useState(0); // Track current image index
    const handlePrevious  = () => {
      if (selectedImageIndex > 0) {
        setSelectedImageIndex(selectedImageIndex - 1);
      }
      else{
        alert("No previous image");
    
      }
    
     };
    
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);

      try {
        // Fetch classes
        const classesResponse = await axios.get(
          `http://localhost:8000/request/requestplatform/${request_id}`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        setClasses(classesResponse.data.data.classes || []);
        setTags(classesResponse.data.data.tags || []);

        // Fetch labelations and regions
        const labelationResponse = await axios.get(
          `http://localhost:8000/request/labelation?linked=${request_id}&x_number=${x_number}&y_number=${y_number}`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        const labelations = labelationResponse.data.data;

        const imagesData = await Promise.all(
            labelations.map(async (labelation) => {
              const regionsResponse = await axios.get(
                `http://localhost:8000/request/label-data?linked=${labelation.id}`,
                { headers: { Authorization: `Bearer ${token}` } }
              );
          
              return {
                src: `http://localhost:8000/media/${request_name}/images/${labelation.Image_name}`,
                Image_number: labelation.Image_number,
                name: labelation.Image_name,
                regions: regionsResponse.data.data.map((region) => ({
                  id: region.region_id,
                  type: region.type,
                  color: region.color,
                  cls: region.class_name,
                  tags: region.tags || [], // Include tags if available, default to an empty array
                  ...(region.type === "box"
                    ? {
                        // Properties for "box" type
                        x: region.x,
                        y: region.y,
                        w: region.w,
                        h: region.h,
                      }
                    : {
                        // Properties for "polygon" type
                        points: region.points , // 
                      }),
                })),
              };
            })
          );
          
        console.log(imagesData);
        setImages(imagesData);
        setOriginalImages(JSON.parse(JSON.stringify(imagesData))); // Deep copy of original state
      } catch (error) {
        console.error("Error fetching verification data:", error);
      }

      setLoading(false);
    };

    fetchData();
  }, [request_id, request_name, x_number, y_number, token]);

 
  if (loading) {
    return <div>Loading...</div>;
  }

  const handleExit = () => {
    alert("Verification completed");
    history.push(
      `/request_dashboard/${request_id}/${request_name}/${p_index}/${status}/verification-tasks`
    );
  };





  const handleSaveAnnotations = async (output) => {
    try {
      
      const currentImage = output.images[selectedImageIndex];
      console.log(currentImage)
      const annotations = {
        Image_name: currentImage.name,
        Image_number: currentImage.Image_number,
        regions: currentImage.regions.map((region) => {
          const isBox = region.type == "box";
          const className = region.cls || classes[0]; // Fallback to first class if `cls` is missing
  
          return {
            id: region.id,
            class_name: className,
            color: region.color,
            type: region.type,
            ...(isBox
              ? {
                  // Box-specific properties
                  x: region.x,
                  y: region.y,
                  w: region.w,
                  h: region.h,
                }
              : {
                  // Polygon-specific properties
                  points: region.points,
                }),
            tags: region.tags || [] // Include tags if available
          };
        }),
      };
  
      // Proceed with saving annotations for the current image
      const date_verified = new Date().toISOString().split("T")[0];
  
      // Save Labelation data
      const labelationResponse = await axios.post(
        `http://localhost:8000/request/labelation/?linked=${request_id}&Image_number=${annotations.Image_number}`,
        {
          linked: request_id,
          Image_name: annotations.Image_name,
          Image_number: annotations.Image_number,
          verified_by: user,
          date_verified: date_verified,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
  
      const labelationId = labelationResponse.data.data.id;
  
      for (const region of annotations.regions) {
        // Save Label Data
        await axios.post(
          `http://localhost:8000/request/label-data/`,
          {
            linked: labelationId,
            class_name: region.class_name,
            color: region.color,
            region_id: region.id,
            tags: region.tags,
            type: region.type,
            ...(region.type === "box"
              ? {
                  // Box-specific payload
                  x: region.x,
                  y: region.y,
                  w: region.w,
                  h: region.h,
                }
              : {
                  // Polygon-specific payload
                  points: region.points, // Array of {x, y} pairs
                }),
          },
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
      }

  
     
      // Extract the annotations for the current image
     
      }
    catch (error) {
      console.error("Error saving annotations:", error);
    }
  };

  const handleNext = async (output) => {
     handleSaveAnnotations(output);

    // Move to the next image if available
    setSelectedImageIndex((prevIndex) => {
      if (prevIndex < images.length - 1) {
        return prevIndex + 1;
      } else {
        alert("You have reached the last image!");
        return prevIndex;
      }
    });
  };

  return (
    <ReactImageAnnotate
      labelImages
      regionClsList={classes}
      regionTagList={tags}
      images={images}
      selectedImage={selectedImageIndex} // Pass the selected image index
      onNextImage={handleNext} // Save and move to the next image
      onPrevImage = {handlePrevious}
      onExit={handleExit} 

    />
  );
};

export default VerificationMakingPage;
