import "../Annotation_tasks/request_annotation_tasks.css"
import { useHistory } from "react-router-dom";

import React, { useState, useEffect } from "react";
import Modal from "react-modal";
import axios from "axios";
import ReactModal from "react-modal";
Modal.setAppElement("#root");

const AnnotationWork = ( {lk_id ,request_name, p_index, status }) => {
  const token = localStorage.getItem("access_token");

  const [isAnnotationModalOpen, setIsAnnotationModalOpen] = useState(false);
  const [isUserShowModalOpen, setIsUserShowModalOpen] = useState(false);
  const [xNumber, setXNumber] = useState("");
  const [yNumber, setYNumber] = useState("");
  const [allUsers, setAllUsers] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [userInputs, setUserInputs] = useState({});
  const [isModalOpenshow, setIsModalOpen] = useState(false);
  const [selectedAnnotatorshow, setSelectedAnnotator] = useState(null);
  const [annotation_tasks_collection , setannotationtaskscollection] = useState([]);
  const [annotation_tasks_collection1 , setannotationtaskscollection1] = useState([]);
  const [ current_task_id, setcurrent_task_id ] = useState(null);

  const [ Annotatorslist , setannotatorslist ] = useState([]);
  const [isopenannotatorslist , setopenannotatorslist] = useState(false);
  const [headerData, setHeaderData] = useState({ total_images: 0, Assigned_verification_images: 0 , Total_verified : 0 });
  const history = useHistory();

  
  const headers = {
    Authorization: `Bearer ${token}`,
  };
  const fetchAnnotatedStats = async (annotation_tasks_collection) => {
    try {
      const updatedTasks = await Promise.all(
        annotation_tasks_collection.map(async (task) => {
          const response = await axios.get(
            `http://localhost:8000/request/track-stats/?linked_id=${lk_id}&x_number=${task.x_number}&y_number=${task.y_number}`,
            { headers }
          );
          return {
            ...task, // Keep the existing task properties
            total_verified: response.data.data.total_verified, // Append the new data
          };
        })
      );
  
      setannotationtaskscollection1(updatedTasks); // Update the state with the modified array
    } catch (error) {
      console.error("Error fetching annotation stats:", error);
    }
  };
  
  
  const fetchannotationtaskData = async (linked) => {
    try {
      const response = await axios.get(`http://localhost:8000/request/assign_verification-tasks/?linked=${linked}` , {headers});
      if (response.data.status==="success"){
        setannotationtaskscollection(response.data.data);
        console.log(annotation_tasks_collection , '--> ')



      }
      else{
        console.log('error while fetching annotation tasks' , response.data.message)
      }
    }catch(error){
      console.log('error while fetching annotation tasks',error);

      
    }
  };
  // Attempting to log updatedTasks here will result in an error, as it's not accessible in this scope.
  


  useEffect(() => {
    const fetchHeaderData = async () => {
      try {
        const response = await axios.get(`http://localhost:8000/request/requestplatform/${lk_id}`, {
          headers,
        });
        const { total_images, Assigned_verification_images  , Total_verified} = response.data.data;
        setHeaderData({ total_images, Assigned_verification_images ,Total_verified});
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchHeaderData();
  }, [annotation_tasks_collection ]); 



  const openModalAnnotatorsList = async (linked) =>{ 
    try{
      const response = await axios.get(`http://localhost:8000/request/task_verification-users/?linked=${linked}`, {headers});
      if (response.data.status==="success"){

        setannotatorslist(response.data.data);
        
        setopenannotatorslist(true);
      }
      else{
        console.log('error while doing openmodalannotatorlist' , response.data.message)
      }




    } catch(error){
      console.log('error while doing openmodalannotatorlist',error);

    }
    
    
  };

  // Function to close the modal
  const closeModalAnnotatorsList = () => setopenannotatorslist(false);

  





 
 

  const openModal = (row) => {
    setSelectedAnnotator(row);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedAnnotator(null);
  };
  useEffect(() => {
   
      axios
        .get("http://localhost:8000/users/", { headers })
        .then((response) => setAllUsers(response.data.data || []))
        .catch((err) => console.error("Error fetching users:", err));
    
  }, []);

  const toggleUserSelection = (user) => {
    setSelectedUsers((prev) =>
      prev.some((u) => u.id === user.id)
        ? prev.filter((u) => u.id !== user.id)
        : [...prev, user]
    );
    setUserInputs((prev) => ({
      ...prev,
      [user.id]: { user_x_number: "", user_y_number: "" },
    }));
  };

  const handleUserInputChange = (userId, field, value) => {
    setUserInputs((prev) => ({
      ...prev,
      [userId]: { ...prev[userId], [field]: value },
    }));
  };

  const handleSubmitAnnotation = async () => {
    try {
      const payload = {
        linked: lk_id,
        x_number: xNumber,
        y_number: yNumber,
        all_verifiers: selectedUsers.map((u) => u.username),
      };
  
      const { data: annotationResponse } = await axios.post(
        "http://localhost:8000/request/assign_verification-tasks/",
        payload,
        { headers }
      );
  
      const assignId = annotationResponse.data.id;
  
      for (const user of selectedUsers) {
        const userPayload = {
          linked: assignId,
          user: user.username,
          user_x_number: userInputs[user.id]?.user_x_number,
          user_y_number: userInputs[user.id]?.user_y_number,
        };
  
        await axios.post("http://localhost:8000/request/task_verification-users/", userPayload, { headers });
      }
  
      alert("Verification work created successfully!");
  
      // Clear all data
      setXNumber("");
      setYNumber("");
      setSelectedUsers([]);
      setUserInputs({});
      setIsAnnotationModalOpen(false);
      setIsUserShowModalOpen(false);
    } catch (error) {
      console.error("Error submitting Verification work:", error);
    }
  };

  const handleUpdateAnnotation = async () => {
    try {
      const payload = {
        linked: lk_id,
        x_number: xNumber,
        y_number: yNumber,
        all_verifiers: selectedUsers.map((u) => u.username),
      };
  
      const { data: annotationResponse } = await axios.put(
        `http://localhost:8000/request/assign_verification-tasks/${current_task_id}/`,
        payload,
        { headers }
      );
  
      const assignId = annotationResponse.data.id;
  
      for (const user of selectedUsers) {
        const userPayload = {
          linked: assignId,
          user: user.username,
          user_x_number: userInputs[user.id]?.user_x_number,
          user_y_number: userInputs[user.id]?.user_y_number,
        };
  
        await axios.post("http://localhost:8000/request/task_verification-users/", userPayload, { headers });
      }
  
      alert("Verification work update successfully!"); 
  
      // Clear all data
      setXNumber("");
      setYNumber("");
      setSelectedUsers([]);
      setUserInputs({});
      setIsAnnotationModalOpen(false);
      setIsUserShowModalOpen(false);
      setcurrent_task_id(null);
    } catch (error) {
      console.error("Error submitting Verification work:", error);
    }
  };


  const handleDeleteAnnotation = async (taskid) => {
    // Show confirmation popup
    const isConfirmed = window.confirm("Are you sure you want to delete this annotation task?");
    
    if (!isConfirmed) {
        return; // Exit if user selects "No"
    }

    try {
        await axios.delete(
            `http://localhost:8000/request/assign_verification-tasks/${taskid}/`,
            { headers }
        );

        alert("Verification work deleted successfully!");
        fetchannotationtaskData(lk_id);
    } catch (error) {
        console.error("Error deleting Verification work:", error);
        alert("Failed to delete Verification work.");
    }
};

  
  const modalHeaderStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px',
    borderBottom: '2px solid #ddd',
    paddingBottom: '10px',
  };
  
  const closeButtonStyle = {
    background: 'none',
    border: 'none',
    fontSize: '20px',
    color: 'red',
    fontWeight: 'bold',
    cursor: 'pointer',
  };
  
  const tableContainerStyle = {
    maxHeight: '1000px',
    overflowY: 'auto',
    marginBottom: '20px',
    border: '1px solid #ddd',
    borderRadius: '8px',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
  };
  
  const tableStyle = {
    width: '100%',
    borderCollapse: 'collapse',
    fontSize: '16px',
  };
  
  const tableHeaderStyle = {
    backgroundColor: '#f4f4f4',
    color: '#333',
    textAlign: 'left',
    fontWeight: 'bold',
  };
  
  const tableRowStyle = {
    borderBottom: '1px solid #ddd',
  };
  
  const tableCellStyle = {
    padding: '10px',
    textAlign: 'left',
  };
  
  const closeButtonContainerStyle = {
    display: 'flex',
    justifyContent: 'center',
  };
  
  const centeredCloseButtonStyle = {
    backgroundColor: '#333',
    color: '#fff',
    padding: '10px 20px',
    border: 'none',
    borderRadius: '4px',
    fontSize: '16px',
    cursor: 'pointer',
  };


  
  useEffect(() => {
    fetchannotationtaskData(lk_id);
   

  },[isAnnotationModalOpen]);
  useEffect(() => {
    fetchAnnotatedStats(annotation_tasks_collection);
  }, [annotation_tasks_collection]); 

  const navigationwork = (x_number, y_number) => {
    const come ="comefromannotationtask";
    history.push(`/verification_work/${lk_id}/${request_name}/${x_number}/${y_number}/${p_index}/${status}/${come}`);
  };


useEffect(()=>{
console.log(selectedUsers, 'selectedusers')
console.log(userInputs, 'userinputs')
console.log(Annotatorslist,'annotatorlist')
},[selectedUsers,userInputs,Annotatorslist]);

const handleupdate2 = async (linked) =>{ 
  try{
    const response = await axios.get(`http://localhost:8000/request/task_verification-users/?linked=${linked}`, {headers});
    if (response.data.status==="success"){

      return (response.data.data);
      
    }
    else{
      console.log('error while doing openmodalannotatorlist' , response.data.message)
    }




  } catch(error){
    console.log('error while doing openmodalannotatorlist',error);

  }
  
  
};

const handleupdate = async (taskid , x_number , y_number , all_verifiers) => {
  
 
  const ss = all_verifiers.map((annotator) => {
    const user = allUsers.find((user) => user.username === annotator);
    return {id : user.id, username: annotator };
  });


  const user_numbers =await handleupdate2(taskid);
   
  const result = ss.reduce((acc, ssItem, index) => {
    const userItem = user_numbers[index]; // Match using the index since lengths are the same
    if (ssItem.username === userItem.user) { // Verify matching username
      acc[ssItem.id] = {
        user_x_number: userItem.user_x_number,
        user_y_number: userItem.user_y_number
      };
    }
    return acc;
  }, {});
  
  


  setSelectedUsers(ss)
  setXNumber( x_number);
  setYNumber(y_number);
  setUserInputs(result);
  setIsAnnotationModalOpen(true);
  setcurrent_task_id(taskid);
};

  return (
    <>
    <div style={{ display: "flex", justifyContent: "flex-start", alignItems: "center", padding: "10px" }}>
      <div
        style={{
          backgroundColor: "white",
          padding: "15px",
          borderRadius: "8px",
          boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
          width: "30pxpx",
          height: "50px"
        }}
      >
        <h4>Total Images: {headerData.total_images} | Assigned Images: {headerData.Assigned_verification_images}  |  Total verified :  {headerData.Total_verified} </h4>
      </div>
    </div>
    <div>
      
       <u><h1 style={{ textAlign: "center", fontWeight: "bold", color: "black" }}>
        Verification Work
      </h1> </u>
      <button
        style={{
          position: "absolute",
          top: "10px",
          right: "10px",
          background: "lightgrey",
        }}
        
        onClick={() => {
          setXNumber("");
          setYNumber("");
          setSelectedUsers([]);
          setUserInputs({});
          setIsAnnotationModalOpen(true);
        }}
      >
       + Add Verification Work
      </button>
 
      <div 
    
       style={{
        maxHeight: "451px",
        overflowY: "auto",
        overflowX: "auto",
        display: "block",
        width: "120%",
         backgroundColor: "white"
      }}
       >
  <table
    style={{
      width: "100%",
      borderCollapse: "collapse",
      border: "1px solid black",
      color: "black",
      textAlign: "center",
      tableLayout: "fixed",
    }}
  >
    <thead>
      <tr>
        {[
          "Date",
          "X_number",
          "Y_number",
          "Annotators",
          "Total Images",
          "Total Verified",
          "Remaining",
          "Action",
        ].map((header) => (
          <th
            key={header}
            style={{
              padding: "10px",
              border: "1px solid black",
              backgroundColor: "darkred",
              color: "white",
              whiteSpace: "nowrap",
              fontSize:"14px"
            }}
          >
            {header}
          </th>
        ))}
      </tr>
    </thead>
    <tbody
      
    >
      {annotation_tasks_collection1.map((task) => (
        <tr key={task.id} >
          <td style={{ padding: "10px", border: "1px solid #ccc" }}>{task.created_at}</td>
          <td style={{ padding: "10px", border: "1px solid #ccc" }}>{task.x_number}</td>
          <td style={{ padding: "10px", border: "1px solid #ccc" }}>{task.y_number}</td>
          <td style={{ padding: "10px", border: "1px solid #ccc" }}>
            <button
              onClick={() => openModalAnnotatorsList(task.id)}
              style={{ 
                padding: "5px",
                fontWeight: "bold", 
                
                border: "1px solid black",
                borderRadius: "3px",
                cursor: "pointer",
              }}
            >
              Show Annotators List
            </button>
            <Modal
              isOpen={isopenannotatorslist}
              onRequestClose={closeModalAnnotatorsList}
              contentLabel="Annotators List"
              className="modal"
              overlayClassName="overlay"
            >
              <div style={modalHeaderStyle}>
                <h2>Annotators List</h2>
                <button onClick={closeModalAnnotatorsList} style={closeButtonStyle}>
                  x
                </button>
              </div>
              <div style={tableContainerStyle} className="table-responsive">
                <table>
                  <thead>
                    <tr>
                      {["Id", "User", "X_number", "Y_number", "Total_images", "Total_verified"].map(
                        (header) => (
                          <th key={header} style={tableHeaderStyle}>
                            {header}
                          </th>
                        )
                      )}
                    </tr>
                  </thead>
                  <tbody>
                    {Annotatorslist.map((annotator) => (
                      <tr key={annotator.id} style={tableRowStyle}>
                        <td style={tableCellStyle}>{annotator.id}</td>
                        <td style={tableCellStyle}>{annotator.user}</td>
                        <td style={tableCellStyle}>{annotator.user_x_number}</td>
                        <td style={tableCellStyle}>{annotator.user_y_number}</td>
                        <td style={tableCellStyle}>{annotator.total_images}</td>
                        <td style={tableCellStyle}>{annotator.total_verified}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div style={closeButtonContainerStyle}>
                <button onClick={closeModalAnnotatorsList} style={centeredCloseButtonStyle}>
                  Close
                </button>
              </div>
            </Modal>
          </td>
          <td style={{ padding: "10px", border: "1px solid #ccc" }}>{task.total_images}</td>
          <td style={{ padding: "10px", border: "1px solid #ccc" }}>{task.total_verified}</td>
          <td style={{ padding: "10px", border: "1px solid #ccc" }}>
            {task.total_images - task.total_verified}
          </td>
            
        
          <td style={{ padding: "10px", border: "1px solid #ccc" }}>
          <button 
  style={{
    padding: "5px",
    backgroundColor: "grey",
    color: "white",
    border: "none",
    borderRadius: "3px",
    cursor: "pointer",
  
 
  }}

  onClick={() => handleupdate(task.id , task.x_number , task.y_number , task.all_verifiers)}
>
  Update
</button>

          <button
           style={{
            padding: "5px",
            backgroundColor: "red",
            color: "white",
            border: "none",
            borderRadius: "3px",
            cursor: "pointer",
          }}

          onClick={() => handleDeleteAnnotation(task.id)}
          
          
          >Delete</button>
        
            <button
              style={{
                padding: "1px",
                backgroundColor: "black",
                color: "white",
                border: "none",
                borderRadius: "3px",
                cursor: "pointer",
              }}

              onClick={() => navigationwork(task.x_number, task.y_number)}
            >
              See Annotated Images
            </button>
          </td>
        </tr>
      ))}
    </tbody>
  </table>
</div>

  
    











      <Modal
  isOpen={isAnnotationModalOpen}
  onRequestClose={() => setIsAnnotationModalOpen(false)}
  className="modal-content"
  overlayClassName="react-modal-overlay" /* Apply this for the overlay */
>
  <div className="modal-header">
    <h2>Verification Work</h2>
    <button onClick={() => setIsAnnotationModalOpen(false)}>x</button>
  </div>
  <div className="section1">
    <h3>Set your target</h3>
    <input
      type="number"
      placeholder="X Number"
      value={xNumber}
      onChange={(e) => setXNumber(e.target.value)}
    />
    <input
      type="number"
      placeholder="Y Number"
      value={yNumber}
      onChange={(e) => setYNumber(e.target.value)}
    />
  </div>
  <div className="section1">
    <h3>Select your annotators</h3>
    <button onClick={() => setIsUserShowModalOpen(true)}>
      List of all your annotators
    </button>
  </div>
  <div className="annotators-box">
    {selectedUsers.map((user, index) => (
      <div className="annotator-item" key={user.id}>
        <span>
          {index + 1}. {user.username}
        </span>
        <input
          type="number"
          placeholder="X"
          value={userInputs[user.id]?.user_x_number}
          onChange={(e) =>
            handleUserInputChange(user.id, "user_x_number", e.target.value)
          }
        />
        <input
          type="number"
          placeholder="Y"
          value={userInputs[user.id]?.user_y_number}
          onChange={(e) =>
            handleUserInputChange(user.id, "user_y_number", e.target.value)
          }
        />
        <button onClick={() => toggleUserSelection(user)}>x</button>
      </div>
    ))}
  </div>
  <button className="submit-btn" onClick={handleSubmitAnnotation}>
    Create
  </button>
  <button className="update-btn" onClick={handleUpdateAnnotation}>
    Update
  </button>
 
 
</Modal>


      <Modal
        isOpen={isUserShowModalOpen}
        onRequestClose={() => setIsUserShowModalOpen(false)}
        className="usershow-modal-content"
        overlayClassName="react-modal-usershow-overlay"
      >
        <div className="usershow-modal-header">
          <h2>List of Users</h2>
          <button onClick={() => setIsUserShowModalOpen(false)}>x</button>
        </div>
        <table className="usershow-table">
          <thead>
            <tr>
              <th>Select</th>
              <th>Username</th>
            </tr>
          </thead>
          <tbody>
            {allUsers.map((user) => (
              <tr key={user.id}>
                <td>
                  <input
                    type="checkbox"
                    checked={selectedUsers.some((u) => u.id === user.id)}
                    onChange={() => toggleUserSelection(user)}
                  />
                </td>
                <td>{user.username}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <button className="confirm-btn" onClick={() => setIsUserShowModalOpen(false)}>
          Confirm
        </button>
      </Modal>
    </div>
    </>
  );
};

export default AnnotationWork;

