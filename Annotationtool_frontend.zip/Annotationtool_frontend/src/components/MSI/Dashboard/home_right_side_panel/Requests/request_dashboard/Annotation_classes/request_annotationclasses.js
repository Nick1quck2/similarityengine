import React, { useState, useEffect } from "react";
import axios from "axios";

const RequestPlatformDetail = ({ id }) => {
  const [requestPlatform, setRequestPlatform] = useState(null);
  const [allClasses, setAllClasses] = useState([]);
  const [selectedClasses, setSelectedClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const isSuperuser = localStorage.getItem("is_superuser");

  const token = localStorage.getItem("access_token");
  const apiUrl = `http://localhost:8000/request/requestplatform/${id}/`;
  const allClassesUrl = `http://localhost:8000/request/api/annotationclasses/`;

  // Fetch RequestPlatform details
  useEffect(() => {
    const fetchRequestPlatform = async () => {
      try {
        setLoading(true);
        const response = await axios.get(apiUrl, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setRequestPlatform(response.data.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchRequestPlatform();
  }, [id, token]);

  // Fetch all available classes
  const fetchAllClasses = async () => {
    try {
      const response = await axios.get(allClassesUrl, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const filteredClasses = response.data.data.filter(
        (cls) => !requestPlatform.classes.some((linkedClass) => linkedClass === cls.name)
      );
      setAllClasses(filteredClasses);
    } catch (err) {
      console.error("Failed to fetch all classes:", err.message);
    }
  };

  // Remove a class
  const handleRemoveClass = async (className) => {
    const confirmRemove = window.confirm(
      `Do you want to remove the class "${className}"?`
    );
    if (!confirmRemove) return;

    try {
      const updatedClasses = requestPlatform.classes.filter(
        (cls) => cls !== className
      );

      await axios.put(
        apiUrl,
        {
          ...requestPlatform,
          classes: updatedClasses,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      setRequestPlatform((prev) => ({
        ...prev,
        classes: updatedClasses,
      }));
    } catch (err) {
      console.error("Failed to remove class:", err.message);
    }
  };

  // Add selected classes
  const handleAddClasses = async () => {
    try {
      const updatedClasses = [
        ...requestPlatform.classes,
        ...selectedClasses.map((cls) => cls.name),
      ];

      await axios.put(
        apiUrl,
        {
          ...requestPlatform,
          classes: updatedClasses,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      setRequestPlatform((prev) => ({
        ...prev,
        classes: updatedClasses,
      }));
      setIsModalOpen(false);
      setSelectedClasses([]);
    } catch (err) {
      console.error("Failed to add classes:", err.message);
    }
  };

  // Toggle class selection
  const toggleClassSelection = (cls) => {
    if (selectedClasses.some((selected) => selected.id === cls.id)) {
      setSelectedClasses((prev) =>
        prev.filter((selected) => selected.id !== cls.id)
      );
    } else {
      setSelectedClasses((prev) => [...prev, cls]);
    }
  };

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;
  if (!requestPlatform || !requestPlatform.classes) return <p>No classes available</p>;

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>{requestPlatform.request_name}</h1>
      {isSuperuser === "true" && (<button
        style={styles.addButton}
        onClick={() => {
          setIsModalOpen(true);
          fetchAllClasses();
        }}
      >
        + ADD Classes
      </button>)}
      <p style={styles.subtitle}>Classes</p>
      <ul style={styles.list}>
        {requestPlatform.classes.map((cls, index) => (
          <li key={index} style={styles.listItem}>
            <span style={styles.className}>
              {index + 1}. {cls}
            </span>
            {isSuperuser === "true" && ( <button
              style={styles.removeButton}
              onClick={() => handleRemoveClass(cls)}
            >
              Remove
            </button>)}
          </li>
        ))}
      </ul>

      {isModalOpen && (
        <div
          id="modal-backdrop"
          style={styles.modalBackdrop}
          onClick={(e) => {
            if (e.target.id === "modal-backdrop") setIsModalOpen(false);
          }}
        >
          <div style={styles.modal}>
            <h2 style={styles.modalTitle}>Select Classes</h2>
            <ul style={styles.modalList}>
              {allClasses.map((cls) => (
                <li key={cls.id} style={styles.modalListItem}>
                  <input
                    type="checkbox"
                    id={`class-${cls.id}`}
                    checked={selectedClasses.some(
                      (selected) => selected.id === cls.id
                    )}
                    onChange={() => toggleClassSelection(cls)}
                  />
                  <label htmlFor={`class-${cls.id}`} style={styles.className}>
                    {cls.name}
                  </label>
                </li>
              ))}
            </ul>
            <div style={styles.modalActions}>
              <button
                style={{
                  ...styles.saveButton,
                  opacity: selectedClasses.length ? 1 : 0.5,
                  cursor: selectedClasses.length ? "pointer" : "not-allowed",
                }}
                onClick={handleAddClasses}
                disabled={!selectedClasses.length}
              >
                Save
              </button>
              <button
                style={styles.closeButton}
                onClick={() => setIsModalOpen(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RequestPlatformDetail;

const styles = {
  container: {
    fontFamily: "'Arial', sans-serif",
    margin: "20px",
    padding: "20px",
    border: "1px solid #ddd",
    borderRadius: "8px",
    maxWidth: "700px",
    backgroundColor: "#f9f9f9",
    overflowY: "auto",
    height: "80vh",
    marginLeft : "170px"
  },
  title: {
    fontSize: "24px",
    color: "#333",
  },
  subtitle: {
    fontSize: "18px",
    color: "#666",
  },
  addButton: {
    backgroundColor: "#3498db",
    color: "#fff",
    border: "none",
    borderRadius: "4px",
    padding: "10px 15px",
    cursor: "pointer",
    marginBottom: "10px",
  },
  list: {
    listStyle: "none",
    padding: 0,
  },
  listItem: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "10px",
    borderBottom: "1px solid #ddd",
  },
  className: {
    fontSize: "16px",
    color: "#444",
    marginLeft: "13px"
  },
  removeButton: {
    backgroundColor: "#e74c3c",
    color: "#fff",
    border: "none",
    borderRadius: "4px",
    padding: "6px 12px",
    cursor: "pointer",
  },
  modalBackdrop: {
    position: "fixed",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    zIndex: 999,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  modal: {
    backgroundColor: "#fff",
    padding: "20px",
    borderRadius: "8px",
    width: "80%",
    maxWidth: "400px",
    boxShadow: "0 4px 10px rgba(0, 0, 0, 0.3)",
    
  },
  modalTitle: {
    fontSize: "20px",
    marginBottom: "10px",
    padding : "10px"
  },
  modalList: {
    listStyle: "none",
    padding: 5,
    marginBottom: "10px",
    maxHeight: "200px",
    overflowY: "auto",
    display: "flex", // Flex layout
    flexDirection: "column", // Stack items vertically
    alignItems: "flex-start", // Align items to the start of the column
    gap: "4",
  },
  modalListItem: {
    display: "flex",
    alignItems: "center",
    marginBottom: "10px", // Space between items (adjust as needed)
    
  },
  modalActions: {
    display: "flex",
    justifyContent: "space-between",
  },
  saveButton: {
    backgroundColor: "#2ecc71",
    color: "#fff",
    border: "none",
    borderRadius: "4px",
    padding: "10px 20px",
    cursor: "pointer",
  },
  closeButton: {
    backgroundColor: "#95a5a6",
    color: "#fff",
    border: "none",
    borderRadius: "4px",
    padding: "10px 20px",
    cursor: "pointer",
  },
};
