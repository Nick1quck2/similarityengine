
import React, { useState, useEffect } from "react";
import axios from "axios";
import "../Annotation_classes/annotation_classes_work.css";

const AnnotationClasses = () => {
  const [annotationClasses, setAnnotationClasses] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedClass, setSelectedClass] = useState(null);
  const [popupType, setPopupType] = useState(null); // 'add', 'update', or 'delete'
  const [popupName, setPopupName] = useState(""); // Name for add or update
  const [showPopup, setShowPopup] = useState(false);
  const isSuperuser = localStorage.getItem("is_superuser");
  // Fetch annotation classes from the API
  useEffect(() => {
    fetchAnnotationClasses();
  }, [annotationClasses]);

  const fetchAnnotationClasses = async () => {
    const token = localStorage.getItem("access_token");
    try {
      const response = await axios.get(
        "http://localhost:8000/request/api/annotationtags/",
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      if (response.data.status === "success") {
        setAnnotationClasses(response.data.data);
      } else {
        console.error(response.data.message);
      }
    } catch (error) {
      console.error("Error fetching annotation classes:", error);
    }
  };

  // Filter annotation classes based on the search term
  const filteredClasses = annotationClasses.filter((annotationClass) =>
    annotationClass.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Open popup for add, update, or delete
  const openPopup = (type, annotationClass = null) => {
    setPopupType(type);
    setSelectedClass(annotationClass);
    setPopupName(annotationClass ? annotationClass.name : "");
    setShowPopup(true);
  };

  // Close the popup
  const closePopup = () => {
    setShowPopup(false);
    setPopupType(null);
    setSelectedClass(null);
    setPopupName("");
  };

  // Handle API request for adding, updating, or deleting
  const handlePopupSubmit = async () => {
    const token = localStorage.getItem("access_token");
  
    try {
      if (popupType === "add") {
        const response = await axios.post(
          "http://localhost:8000/request/api/annotationtags/",
          { name: popupName },
          { headers: { Authorization: `Bearer ${token}` } }
        );
  
        if (response.data.status === "success") {
          setAnnotationClasses((prev) => [...prev, response.data.data]);
          alert("Added successfully!");
        }
      } else if (popupType === "update") {
        const response = await axios.put(
          `http://localhost:8000/request/api/annotationtags/${selectedClass.id}/`,
          { name: popupName },
          { headers: { Authorization: `Bearer ${token}` } }
        );
  
        if (response.data.status === "success") {
          setAnnotationClasses((prev) =>
            prev.map((item) =>
              item.id === selectedClass.id
                ? { ...item, name: popupName }
                : item
            )
          );
          alert("Updated successfully!");
        }
      } else if (popupType === "delete") {
        const response = await axios.delete(
          `http://localhost:8000/request/api/annotationtags/${selectedClass.id}/`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
  
        if (response.data.status === "success") {
            
          setAnnotationClasses((prev) =>
            prev.filter((item) => item.id !== selectedClass.id)
          ); // Remove the deleted item from the state

          alert("Deleted successfully!");
        }
      }
  
      closePopup(); // Ensure popup closes after a successful operation
    } catch (error) {
      console.error(`Error performing ${popupType} operation:`, error);
    }
  };
  
  return (
    <div className="annotation-classes-container">
      <h1>Annotation Tags</h1>
      <div className="filter-container">
        <input
          type="text"
          placeholder="Filter by search"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        
        {isSuperuser === "true" && ( <button className="add-btn" onClick={() => openPopup("add")}>
    + Add Tags
  </button>)}

      </div>
  
      <div className="classes-list">
        {filteredClasses.map((annotationClass, index) => (
          <div className="class-item" key={annotationClass.id}>
            <span className="class-index" style={{ color: "green", marginRight: "10px" }}>
              {index + 1}.
            </span>
            <span>{annotationClass.name}</span>
            <div className="class-actions">
            {isSuperuser === "true" && ( <button
                className="update-btn"
                onClick={() => openPopup("update", annotationClass)}
              >
                Update
              </button>)}

             {isSuperuser === "true" && ( <button
                className="delete-btn"
                onClick={() => openPopup("delete", annotationClass)}
              >
                Delete
              </button>)}
            </div>
          </div>
        ))}
      </div>
  
      {showPopup && (
        <div className="popup-overlay">
          <div className="popup">
            <button className="close-btn" onClick={closePopup}>
              ×
            </button>
            {popupType === "delete" ? (
              <>
                <h2>Are you sure you want to delete this annotation tag?</h2>
                <p>{selectedClass?.name}</p>
                <div className="popup-actions">
                  <button className="ok-btn" onClick={handlePopupSubmit}>
                    Yes
                  </button>
                  <button className="cancel-btn" onClick={closePopup}>
                    No
                  </button>
                </div>
              </>
            ) : (
              <>
                <h2>{popupType === "add" ? "Add" : "Update"} Annotation Tags</h2>
                <input
                  type="text"
                  placeholder="Class Name"
                  value={popupName}
                  onChange={(e) => setPopupName(e.target.value)}
                />
                <div className="popup-actions">
                  <button className="ok-btn" onClick={handlePopupSubmit}>
                    Submit
                  </button>
                  <button className="cancel-btn" onClick={closePopup}>
                    Cancel
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default AnnotationClasses;
