import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Notifications = () => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const username = localStorage.getItem('username');
  const token = localStorage.getItem('access_token');

  useEffect(() => {
    // Fetch tasks from the API
    const fetchNotifications = async () => {
      try {
        const response = await axios.get('http://localhost:8000/request/user-tasks/', {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
          params: {
            username: username,
          },
        });
        setNotifications(response.data.data);
      } catch (error) {
        setError('Error fetching tasks.');
      } finally {
        setLoading(false);
      }
    };

    fetchNotifications();
  }, [username, token]);

  return (
    <div style={styles.notificationPanel}>
      <div style={styles.notificationHeader}>
        <h2 style={styles.headerTitle}>Notifications</h2>
      </div>

      {loading && <div style={styles.loading}>Loading...</div>}
      {error && <div style={styles.error}>{error}</div>}

      <div style={styles.notificationList}>
        {notifications.map((notification, index) => (
          <div key={index} style={styles.notificationItem}>
            <div style={styles.notificationInfo}>
              <p>{notification.task_info}</p>
              <span style={styles.timestamp}>
                {new Date(notification.created_at).toLocaleString()}
              </span>
            </div>
            <div style={styles.notificationFooter}>
              <span style={styles.totalImages}>
                {notification.total_images} Images
              </span>
            </div>
          </div>
        ))}
      </div>

      <div style={styles.scrollIndicator}>
        <p>Scroll for more...</p>
      </div>
    </div>
  );
};

const styles = {
  notificationPanel: {
    width: '1050px',
    maxHeight: '900px',
    backgroundColor: '#f8f9fa',
    borderRadius: '8px',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
    overflowY: 'auto',
    padding: '20px',
    position: 'fixed',
    right: '20px',
    top: '30px',
  },
  notificationHeader: {
    textAlign: 'center',
    marginBottom: '10px',
  },
  headerTitle: {
    fontSize: '18px',
    fontWeight: '600',
    color: '#6c5ce7',
  },
  notificationList: {
    maxHeight: '400px',
    overflowY: 'auto',
  },
  notificationItem: {
    backgroundColor: '#ffffff',
    border: '1px solid #e1e1e1',
    borderRadius: '6px',
    padding: '12px',
    marginBottom: '15px',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
  },
  notificationInfo: {
    fontSize: '14px',
    color: '#333',
  },
  timestamp: {
    fontSize: '12px',
    color: '#888',
    marginTop: '5px',
  },
  notificationFooter: {
    display: 'flex',
    justifyContent: 'space-between',
    marginTop: '8px',
  },
  totalImages: {
    fontSize: '12px',
    color: '#6c5ce7',
  },
  scrollIndicator: {
    textAlign: 'center',
    fontSize: '12px',
    color: '#bbb',
    marginTop: '20px',
  },
  loading: {
    textAlign: 'center',
    color: '#888',
  },
  error: {
    color: 'red',
    textAlign: 'center',
  },
};

export default Notifications;
