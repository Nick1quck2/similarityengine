import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';  // Use Switch and Route from v5
import Test from "./test";
import Login from "./components/Authentication/Login";
import MSI_Home_Dashboard from "./components/MSI/Dashboard/home"
import CreateRequest from "./components/MSI/Dashboard/home_right_side_panel/Requests/requests_creation"
import RequestDashboard from "./components/MSI/Dashboard/home_right_side_panel/Requests/requests_dashboard"
import Annotation_work from "./components/AnnotationPlatform/Annotation_work/rough"
import Verification_work from "./components/AnnotationPlatform/Verification_work/rough"
function App() {
    return (
       
        <Router>
            <Switch>  
                <Route exact path="/" component={Login} /> 
                
                 <Route path="/home_dashboard" component={MSI_Home_Dashboard} />
                 <Route path='/create_request' component={CreateRequest} />
                <Route path="/request_dashboard/:id/:request_name/:p_index/:status/:section" component={RequestDashboard} /> 
                <Route path="/annotation_work/:request_id/:request_name/:x_number/:y_number/:p_index/:status" component={Annotation_work}/>
                <Route path="/verification_work/:request_id/:request_name/:x_number/:y_number/:p_index/:status/:come" component={Verification_work}/>

                <Route path="/test" component={Test} />
                                                            
            </Switch>
        </Router>
    );
}

export default App;
