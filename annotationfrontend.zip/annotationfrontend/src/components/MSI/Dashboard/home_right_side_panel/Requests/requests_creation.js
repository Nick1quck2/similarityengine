import React, { useState, useEffect } from "react";
import "./requests_creation.css";
import { useHistory} from "react-router-dom";
import axios from "axios";
import Modal from "react-modal";

const CreateProject = () => {
  const history = useHistory();

  // States
  const [projectName, setProjectName] = useState("");
  const [task, setTask] = useState("");
  const [instructions, setInstructions] = useState("");
  const [dataInfo, setDataInfo] = useState("");
  const [annotationClasses, setAnnotationClasses] = useState([]);
  const [selectedClasses, setSelectedClasses] = useState([]);
  const [images, setImages] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const token = localStorage.getItem("access_token");

  // Fetch annotation classes
  useEffect(() => {
    axios
      .get("http://localhost:8000/request/api/annotationclasses/",   {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => setAnnotationClasses(response.data.data))
      .catch((error) => console.error("Error fetching annotation classes:", error));
  }, []);

  // Handle project submission
  const handleSubmit = async () => {
    try {
      // Step 1: Create RequestPlatform entry
      const requestPlatformResponse = await axios.post("http://localhost:8000/request/requestplatform/",  
        {
        request_name: projectName,
        task:task,
        classes: selectedClasses.map((cls) => cls.name),
        instructions:instructions,
        data_info: dataInfo,
      } ,     { headers: {
        Authorization: `Bearer ${token}`,
      },
    }  );

      console.log(requestPlatformResponse , '-------');

      const requestPlatformId = requestPlatformResponse.data.data.id;

      // Step 2: Upload images linked to the created RequestPlatform
      

      // Success alert and navigation
      alert("Request created successfully!");
      history.push("/home_dashboard");
    } catch (error) {
      console.error("Error creating request:", error);
      alert("Failed to create request.");
    }
  };

  // Handle class selection
  const handleClassSelection = (cls) => {
    if (selectedClasses.includes(cls)) {
      setSelectedClasses(selectedClasses.filter((c) => c !== cls));
    } else {
      setSelectedClasses([...selectedClasses, cls]);
    }
  };

  // Handle image uploads
  const handleImageUpload = (event) => {
    setImages([...images, ...event.target.files]);
  };

  return (
    <div className="project-page-container">
      {/* First Section */}
      <div className="header-section">
        <img src="./Annotafusion_Logo.png" alt="Annotafusion Logo" className="logo" />
        <button className="close-button" onClick={() =>   history.push("/home_dashboard")}>
          ✖
        </button>
      </div>

      {/* Second Section */}
      <div className="content-section">
        <h1 className="heading">Let&apos;s create your request</h1>

        {/* Project Name */}
        <div className="form-group">
          <label>Request Name</label>
          <input type="text" value={projectName} onChange={(e) => setProjectName(e.target.value)} />
        </div>

        {/* Task */}
        <div className="form-group">
          <label>Task</label>
          <input type="text" value={task} onChange={(e) => setTask(e.target.value)} />
        </div>

        {/* Annotation Classes */}
        <div className="form-group">
          <label>Annotation Classes</label>
          <button className="list-button" onClick={() => setIsModalOpen(true)}>
            List of classes
          </button>
          <div className="selected-classes">
            {selectedClasses.map((cls) => (
              <span key={cls.id} className="class-chip">
                {cls.name}
                <button onClick={() => handleClassSelection(cls)}>✖</button>
              </span>
            ))}
          </div>
        </div>

        {/* Instructions */}
        <div className="form-group">
          <label>Instructions</label>
          <input
            type="text"
            value={instructions}
            onChange={(e) => setInstructions(e.target.value)}
          />
        </div>

        {/* Data Info */}
        <div className="form-group">
          <label>Data Info</label>
          <input type="text" value={dataInfo} onChange={(e) => setDataInfo(e.target.value)} />
        </div>

        {/* Upload Images */}
        <div className="form-group">
  
</div>

        {/* Submit Button */}
        <button className="submit-button" onClick={handleSubmit}>
  Submit
</button>
<button
  className="cancel-button"
  onClick={() =>   history.push("/home_dashboard")}
>
  Cancel
</button>
      </div>

      {/* Annotation Classes Modal */}
      <Modal isOpen={isModalOpen} onRequestClose={() => setIsModalOpen(false)} className="modal">
        <h2>Select Annotation Classes</h2>
        <div className="class-list">
          {annotationClasses.map((cls) => (
            <div key={cls.id}>
              <input
                type="checkbox"
                checked={selectedClasses.includes(cls)}
                onChange={() => handleClassSelection(cls)}
              />
              {cls.name}
            </div>
          ))}
        </div>
        <button className="close-modal" onClick={() => setIsModalOpen(false)}>
          Close
        </button>
      </Modal>
    </div>
  );
};

export default CreateProject;
