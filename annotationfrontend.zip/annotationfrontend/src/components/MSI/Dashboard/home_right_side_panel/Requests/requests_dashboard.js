import React, { useState, useEffect }  from "react";
import { useLocation, useHistory, useParams } from "react-router-dom";
import "./requests_dashboard.css";
import AnnotationClasses from "./request_dashboard/Annotation_classes/request_annotationclasses"
import AnnotationTasks from "./request_dashboard/Annotation_tasks/request_annotation_tasks"
import VerificationTasks from "./request_dashboard/Verification_tasks/request_verification_tasks"
import Imageswork from "./request_dashboard/Images_work/request_imagework"
import Annotatorwork from "./request_dashboard/Annotators_work/request_annotation_details"
import Verificationwork from "./request_dashboard/Annotators_Verifiers_work/request_verification_details"
import Download_work from "./downloadpage"

const ProjectHomePage = () => {
  const history = useHistory();

    const { id, request_name, p_index, status, section } = useParams();
    useEffect(() => {
      handleSectionClick(section);
    },[section]);

  console.log(id, request_name, p_index, status,section);
  
  const isSuperuser = localStorage.getItem("is_superuser");


  const [activeSection, setActiveSection] = useState("Welcome");
  const [componentToRender, setComponentToRender] = useState(
    <div className="content-area">
    {/* Add your right panel components or dynamic content here */}
    <h2>Welcome to the Home Dashboard</h2>
    <p>Select an option from the left panel to get started.</p>
    </div>
  );

  // Extract data from location.state

  
  


  const handleSectionClick = (section) => {
    setActiveSection(section);

    switch (section) {
      
        

      case "request-name":
        setComponentToRender(
          <div className="content-area">
    {/* Add your right panel components or dynamic content here */}
    <h2>Welcome to the Home Dashboard</h2>
    <p>Select an option from the left panel to get started.</p>
    </div>
        );
        break;
      case "images":
        setComponentToRender(<Imageswork  lk_id={request_name}  />);
        break;
     
      case "annotation-classes":
        setComponentToRender(<AnnotationClasses  id={id}/>);
        break;
      
      case "annotation-tasks":
        setComponentToRender( <div> {isSuperuser === 'true' ? (
          // Render AnnotationTasks if isSuperuser is 'true'
          <AnnotationTasks lk_id={id} request_name={request_name} p_index={p_index} status={status} />
        ) : (
          // Otherwise, render Annotatorwork
          <Annotatorwork linked={id}  request_name={request_name} p_index={p_index} status={status} />
        )}  </div> );
        break;
      case "verification-tasks":
        setComponentToRender(<div> {isSuperuser === 'true' ? (<VerificationTasks lk_id = {id} request_name={request_name} p_index={p_index} status={status} />) : (<Verificationwork  linked={id}   request_name={request_name} p_index={p_index} status={status}  />)}</div>);
        break;
     
      case "download-annotations":
        setComponentToRender(<Download_work  request_id={id}  request_name={request_name} />);
        break;
      
        
       
          break;
      case "Logout":
        localStorage.clear();
        window.location.href = "/"; // Redirect to login page
        break;
      default:
        setComponentToRender(<div>Default Content</div>);
    }
  };


  


  // Handle button navigation
  const handleNavigation = (path) => {
    setComponentToRender(<div></div>)
    // Implement logic here for each button's functionality
  };

  return (
    <div className="project-home-container">
      {/* Left Panel */}
      <div className="left-panel">
        {/* First Section */}
        <div  onClick={() => handleSectionClick('request-name')} className="section first-section">
          <div className="p-index-circle">{p_index}</div>
          <div className="request-name">{request_name}</div>
          <div className="status-info">
            Status:{" "}
            <span
              className={`status-bulb ${
                status === "Running"
                  ? "green"
                  : status === "Complete"
                  ? "red"
                  : "blue"
              }`}
            ></span>{" "}
            {status}
          </div>
        </div>

        {/* Buttons Section */}
        <div className="section buttons-section">
          <button onClick={() => handleSectionClick("images")}>Images</button>
          <button onClick={() => handleSectionClick("annotation-classes")}>Annotation Classes</button>

          <button onClick={() => handleSectionClick("annotation-tasks")}>Annotation Tasks</button>
          <button onClick={() => handleSectionClick("verification-tasks")}>Verification Tasks</button>
          <button onClick={() => handleSectionClick("download-annotations")}>Download the Annotation</button>
          
        </div>
        <button className="section logout-section" onClick={() => handleSectionClick("Logout")}>
          LOG OUT
        </button>
      </div>

      {/* Right Panel */}
      <div className="right-panel">
        <div className="top-bar">
        <button className="back-button" onClick={() =>   history.push("/home_dashboard")}>
        <u>Back to Dashboard</u>
          </button> 
        </div>
       
          <div className="right-panel">
        <div className="dynamic-content">{componentToRender}</div>
     
        
      </div>
    </div>
    </div>
  );
};

export default ProjectHomePage;
