import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './request_imagework.css';
import {   useHistory } from 'react-router-dom';  // Import useNavigate

const ImagesPage = ({ lk_id }) => {
  const [images, setImages] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalImages, setTotalImages] = useState(0);
  const [isPopupOpen, setIsPopupOpen] = useState(false); // Popup visibility state
  const [selectedFolder, setSelectedFolder] = useState(null); // Store selected folder
  const [selectedImage, setSelectedImage] = useState(null); // Store selected image for modal
  const token = localStorage.getItem("access_token");
  const [inputPage, setInputPage] = useState('');
  const history = useHistory();
  const isSuperuser = localStorage.getItem("is_superuser");
  const handleSearch = () => {
    // Update page based on the value in the input box
    if (inputPage && !isNaN(inputPage) && inputPage > 0) {
      setPage(Number(inputPage));
      setInputPage('');
    } else {
      alert("Please enter a valid page number.");
    }
  };

  const fetchImages = async () => {
    try {
      const response = await axios.get(
        `http://localhost:8000/request/images1/${lk_id}/?page=${page}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setImages(response.data.results.data || []); // Handle cases where data might be empty
      const calculatedPages = Math.ceil(response.data.count / 20);
      setTotalPages(calculatedPages);
      setTotalImages(response.data.count);
    } catch (error) {
      console.error('Error fetching images:', error);
    }
  };

  useEffect(() => {
    fetchImages();
  }, [page, lk_id, token]); 

  const handleNextPage = () => {
    if (page < totalPages) {
      setPage((prevPage) => prevPage + 1);
    }
  };

  const handlePreviousPage = () => {
    if (page > 1) {
      setPage((prevPage) => prevPage - 1);
    }
  };

  const handleUploadClick = () => {
    setIsPopupOpen(true); // Open the popup
  };

  const handleClosePopup = () => {
    setIsPopupOpen(false); // Close the popup
  };

  const handleImageClick = (image) => {
    setSelectedImage(image); // Set the selected image for modal
  };

  const handleCloseModal = () => {
    setSelectedImage(null); // Close the modal
  };

  const handleUpdateImage = async () => {
    if (!selectedImage || !selectedImage.newImage) {
      alert("Please select a new image to update!");
      return;
    }
    
    try {
      const formData = new FormData();
      formData.append("image", selectedImage.newImage);

      const response = await axios.put(
        `http://localhost:8000/request/images1/${lk_id}/${selectedImage.id}/`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      alert("Image updated successfully!");
      setSelectedImage(response.data.data);

      fetchImages(); // Refresh images after update
      // handleCloseModal(); // Close the modal
    } catch (error) {
      console.error("Error updating image:", error);
      alert("An error occurred while updating the image.");
    }
  };

  const handleDeleteImage = async () => {
    try {
      await axios.delete(
        `http://localhost:8000/request/images1/${lk_id}/${selectedImage.id}/`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      alert("Image deleted successfully!");
      fetchImages(); // Refresh images after delete
      handleCloseModal(); // Close the modal
    } catch (error) {
      console.error("Error deleting image:", error);
      alert("An error occurred while deleting the image.");
    }
  };

  const renderTableCells = () => {
    const rows = [];
    for (let i = 0; i < 5; i++) {
      const cells = [];
      for (let j = 0; j < 4; j++) {
        const imageIndex = i * 4 + j;
        if (imageIndex < images.length) {
          cells.push(
            <td key={j} className="image-cell" onClick={() => handleImageClick(images[imageIndex])}>
              <img
                src={`http://127.0.0.1:8000/${images[imageIndex].url}`}
                alt={`Image ${imageIndex + 1}`}
                className="image-thumbnail"
              />
            </td>
          );
        } else {
          cells.push(<td key={j} className="image-cell null-cell">NULL</td>);
        }
      }
      rows.push(<tr key={i}>{cells}</tr>);
    }
    return rows;
  };
  const handleUploadSubmit = async () => {
    if (!selectedFolder) {
      alert("Please select a folder first!");
      return;
    }
  
    try {
      for (const file of selectedFolder) {
        const formData = new FormData();
        formData.append("image", file);
        formData.append("lk_id", lk_id);
  
        await axios.post(`http://127.0.0.1:8000/request/images1/${lk_id}/create/`, formData, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
      }
  
      alert("All images uploaded successfully!");
      setIsPopupOpen(false); // Close the popup after successful upload
      setSelectedFolder(null); // Clear the selected folder
  
      // Re-fetch images to show the live update
      fetchImages();
    } catch (error) {
      console.error("Error uploading images:", error);
      alert("An error occurred during upload. Please try again.");
    }
  };
  

  return (
    <div className="images-page">
      <header className="images-header">
        <h1 style={{ color: "black" }}>Images</h1>
        <label htmlFor="pageSearch">Page Search: </label>
        <input
          type="number"
          id="pageSearch"
          value={inputPage}
          onChange={(e) => setInputPage(e.target.value)}  // Update input value
          style={{
            border: '2px solid #ccc',
            borderRadius: '4px',
            padding: '5px 10px',
            marginRight: '10px',
            outline: 'none',
          }}
          onFocus={(e) => e.target.style.border = '2px solid blue'}  // Blue border on focus
          onBlur={(e) => e.target.style.border = '2px solid #ccc'}   // Reset border on blur
        />
        
        {/* Search Button */}
        <button
          onClick={handleSearch}
          style={{
            padding: '5px 15px',
            backgroundColor: 'blue',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          Search
        </button>        
        {isSuperuser === "true" && (  <button
          style={{ backgroundColor: "darkblue" }}
          className="upload-btn"
          onClick={handleUploadClick}
        >
          Upload Data
        </button>)}
      </header>
      <div className="pagination-info">
        <span>
          <button
            style={{
              borderRadius: '5px',
              marginRight: '76px',
              backgroundColor: 'green',
              color: 'white',
              padding: '10px 15px',
              cursor: 'pointer',
              border: 'none',
              boxShadow: '0px 4px 6px rgba(0, 0, 0, 0.1)',
              transition: 'all 0.3s ease',
            }}
            onMouseEnter={(e) => {
              e.target.style.backgroundColor = 'darkred';
              e.target.style.boxShadow = '0px 6px 8px rgba(0, 0, 0, 0.2)';
            }}
            onMouseLeave={(e) => {
              e.target.style.backgroundColor = 'green';
              e.target.style.boxShadow = '0px 4px 6px rgba(0, 0, 0, 0.1)';
            }}
            onClick={handlePreviousPage}
            disabled={page <= 1 || totalPages === 0}
          >
            Previous
          </button>
          <u>
            Page {page} of {totalPages} (Total Images: {totalImages})
          </u>
          <button
            style={{
              borderRadius: '5px',
              marginLeft: '76px',
              backgroundColor: 'red',
              color: 'white',
              padding: '10px 15px',
              cursor: 'pointer',
              border: 'none',
              boxShadow: '0px 4px 6px rgba(0, 0, 0, 0.1)',
              transition: 'all 0.3s ease',
            }}
            onMouseEnter={(e) => {
              e.target.style.backgroundColor = 'darkred';
              e.target.style.boxShadow = '0px 6px 8px rgba(0, 0, 0, 0.2)';
            }}
            onMouseLeave={(e) => {
              e.target.style.backgroundColor = 'red';
              e.target.style.boxShadow = '0px 4px 6px rgba(0, 0, 0, 0.1)';
            }}
            onClick={handleNextPage}
            disabled={page >= totalPages || totalPages === 0}
          >
            Next
          </button>
        </span>
      </div>
      <div className="images-table-wrapper">
        <table className="images-table">
          <tbody>{renderTableCells()}</tbody>
        </table>
      </div>

      {/* Image Modal */}
      {selectedImage && (
        <div className="modal-overlay">
          <div className="modal-content1">
            <button onClick={handleCloseModal} className="close-btn">X</button>
            <img
              src={`http://127.0.0.1:8000/${selectedImage.url}`}
              alt="Selected"
              className="modal-image"
            />
            <div className="modal-actions">
            {isSuperuser === "true" && ( <input
                type="file"
                onChange={(e) => setSelectedImage({ ...selectedImage, newImage: e.target.files[0] })}
              />)}
             {isSuperuser === "true" && ( <button style ={{backgroundColor : "darkblue"}} onClick={handleUpdateImage}>Update</button>)}
             {isSuperuser === "true" && ( <button  style ={{backgroundColor : "red"}}  onClick={handleDeleteImage}>Delete</button>)}
            </div>
          </div>
        </div>
      )}

      {/* Popup Modal */}
      {isPopupOpen && (
        <div className="popup-overlay">
          <div className="popup-content">
            <h2>Upload Images</h2>
            <input
              type="file"
              multiple
              webkitdirectory="true"
              onChange={(e) => setSelectedFolder(e.target.files)}
            />
            <div className="popup-buttons">
              <button onClick={handleUploadSubmit}>Submit</button>
              <button onClick={handleClosePopup}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ImagesPage;
