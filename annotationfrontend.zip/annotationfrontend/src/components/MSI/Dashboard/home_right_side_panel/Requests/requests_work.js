import React, { useState, useEffect } from "react";
import {   useHistory } from "react-router-dom";
import "./requests_work.css"; // Import the CSS file for styling
import axios from "axios";

const Projects = () => {
  const history = useHistory();

  const [projects, setProjects] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [dateFilter, setDateFilter] = useState("");
  const [selectedProject, setSelectedProject] = useState(null);
  const isSuperuser = localStorage.getItem("is_superuser");
  const token = localStorage.getItem("access_token");
  const [activePopup, setActivePopup] = useState(null);
  

  // Fetch projects from API
  const fetchProjects = async () => {
      
    try {
      const response = await axios.get(
        "http://localhost:8000/request/requestplatform/",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.data.status === "success") {
        
        setProjects(response.data.data);
      } else {
        console.error(response.data.message);
      }
    } catch (error) {
      console.error("Error fetching projects:", error);
    }
  };
  useEffect(() => {
   

    fetchProjects();
  }, []);

  const deleteproject= async (index)=>{
    try{
    const response = await axios.delete(`http://localhost:8000/request/requestplatform/${index}` ,{
      headers: {
        Authorization: `Bearer ${token}`,
      },
    } )

    if (response.data.status === "success") {
      fetchProjects();
      
      alert("Request deleted successfully")

    } else {
      console.error(response.data.message);
    }

  } catch (error) {
    console.error("Error while deleting project:", error);
  }

  }

  // Filter projects based on search term and date filter
  const filteredProjects = projects.filter((project) => {
    const matchesSearchTerm = project.request_name
      .toLowerCase()
      .includes(searchTerm.toLowerCase());
    const matchesDateFilter = dateFilter
      ? project.created_at.startsWith(dateFilter)
      : true;
    return matchesSearchTerm && matchesDateFilter;
  });

  // Handle project click to navigate to Projectdashboard
  const handleProjectClick = (project, index) => {
    // Set selected project state for dynamic rendering
    setSelectedProject({
      id: project.id,
      p_index: `P${index + 1}`,
      request_name: project.request_name,
      status: project.status,
    });

    // Navigate to the Projectdashboard component, passing state
    history.push(`/request_dashboard/${project.id}/${project.request_name}/${`R${index + 1}`}/${project.status}/${"request-name"}`
);
  };

  const handleNewProjectClick = () => {
    history.push("/create_request");
  };

  return (
    <div className="projects-page">
      {/* Header Section */}
      <div className="header">
      {isSuperuser === "true" && ( <button className="new-project-btn" onClick={handleNewProjectClick}>+ Create Request</button>)}
        <u><h1 style={{color : "green"}} >Requests</h1></u>
        <div className="filters">
          <input
            type="text"
            placeholder="Search by Name"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <input
            type="date"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
          />
        </div>
      </div>

      {/* Conditional Rendering */}
      {!selectedProject ? (
        <div className="projects-list">
          {filteredProjects.map((project, index) => (
            <div
              className="project-box"
              key={project.id}
              onClick={() => handleProjectClick(project, index)}
            >
              <div className="project-header">
                <span className="project-index">R{index + 1}</span>
                <h3 style={{ color: "black" }}  >{project.request_name}</h3>
                

              </div>
              <p className="project-info">{project.data_info}</p>
              <p className="project-date">
                Created At: {new Date(project.created_at).toLocaleDateString()}
              </p>
              <div className="project-stats">
              <span style={{ color: "black", display: "inline-block", marginRight: "20px" }}>
    Total Images: {project.total_images || "0"}
  </span>
  <span style={{ color: "black", display: "inline-block", marginRight: "20px" }}>
    Total Annotated: {project.Total_annotated || "0"}
  </span>
  <span style={{ color: "black", display: "inline-block", marginRight: "20px" }}>
    Total Verified: {project.Total_verified || "0"}
  </span>

                <span className="project-status">
                  {project.status === "Running" && (
                    <span className="status-bulb green"></span>
                  )}
                  {project.status === "Complete" && (
                    <span className="status-bulb red"></span>
                  )}
                  {project.status === "Pause" && (
                    <span className="status-bulb blue"></span>
                  )}
                  {project.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        // Render Projectdashboard dynamically
        <></>
       
      )}
    </div>
  );
};

export default Projects;
