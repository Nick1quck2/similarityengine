import React, { useState, useEffect } from "react";
import { useParams, useHistory } from "react-router-dom";
import axios from "axios";
import ReactImageAnnotate from "react-image-annotate";

const VerificationMakingPage = () => {
  const { request_id, request_name, x_number, y_number, p_index, status , come  } = useParams();
  const history = useHistory();
  const token = localStorage.getItem("access_token");
  const user = localStorage.getItem("username");
  console.log(come,'------------------come');

  const [classes, setClasses] = useState([]);
  const [images, setImages] = useState([]);
  const [originalImages, setOriginalImages] = useState([]); // To store the original state
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);

      try {
        // Fetch classes
        const classesResponse = await axios.get(
          `http://localhost:8000/request/requestplatform/${request_id}`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        setClasses(classesResponse.data.data.classes || []);

        // Fetch labelations and regions
        const labelationResponse = await axios.get(
          `http://localhost:8000/request/labelation?linked=${request_id}&x_number=${x_number}&y_number=${y_number}`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        const labelations = labelationResponse.data.data;

        const imagesData = await Promise.all(
          labelations.map(async (labelation) => {
            const regionsResponse = await axios.get(
              `http://localhost:8000/request/label-data?linked=${labelation.id}`,
              { headers: { Authorization: `Bearer ${token}` } }
            );
            return {
              src: `http://localhost:8000/media/${request_name}/images/${labelation.Image_name}`,
              Image_number: labelation.Image_number,
              name: labelation.Image_name,
              regions: regionsResponse.data.data.map((region) => ({
                id: region.region_id,
                type: "box",
                color: region.color,
                cls: region.class_name,
                x: region.x,
                y: region.y,
                w: region.w,
                h: region.h,
              })),
            };
          })
        );

        setImages(imagesData);
        setOriginalImages(JSON.parse(JSON.stringify(imagesData))); // Deep copy of original state
      } catch (error) {
        console.error("Error fetching verification data:", error);
      }

      setLoading(false);
    };

    fetchData();
  }, [request_id, request_name, x_number, y_number, token]);

  const handleExit = async (output) => {
    const annotations = output.images.map((image) => {
      // Find the corresponding original image
      const originalImage = originalImages.find((img) => img.name === image.name);

      // Ensure originalImage exists to avoid errors
      if (!originalImage) {
        console.error(`Original image not found for: ${image.name}`);
        return null; // Skip this image if not found
      }

      const Image_number = originalImage.Image_number;

      // Return the annotation object
      return {
        Image_name: image.name,
        Image_number: Image_number,
        regions: image.regions.map((region) => ({
          id: region.id,
          class_name: region.cls, // Class name
          color: region.color,
          x: region.x, // Bounding box x
          y: region.y, // Bounding box y
          w: region.w, // Bounding box width
          h: region.h, // Bounding box height
        })),
      };
    });

    // Filter out any null entries
    const filteredAnnotations = annotations.filter((annotation) => annotation !== null);

    console.log("Filtered Annotations:", filteredAnnotations);

    // Update the labelation and regions if there are changes
    for (const annotation of filteredAnnotations) {
      try {
        const date_verified = new Date().toISOString().split('T')[0]; // Gets today's date in YYYY-MM-DD format

        // Update/Create Labelation
        const labelationResponse = await axios.post(
          `http://localhost:8000/request/labelation/?linked=${request_id}&Image_number=${annotation.Image_number}`,
          {
            linked: request_id, // RequestPlatform ID
            Image_name: annotation.Image_name, // Image name
            Image_number: annotation.Image_number, // Image number
            verified_by: user, // Replace with the current user's username
            date_verified : date_verified 
          },
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        const labelationId = labelationResponse.data.data.id; // ID of created Labelation

        // Save Label_data for the regions (POST based on region state)
        for (const region of annotation.regions) {
          await axios.post(
            `http://localhost:8000/request/label-data/`,
            {
              linked: labelationId, // Link to the created Labelation
              class_name: region.class_name, // Class name
              color: region.color,
              region_id: region.id,
              x: region.x,
              y: region.y,
              w: region.w,
              h: region.h,
            },
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );
        }
      } catch (error) {
        console.error("Error updating labelation and regions:", error);
      }
    }
   

    alert("Verification complete!");
    
    
    history.push(`/request_dashboard/${request_id}/${request_name}/${p_index}/${status}/verification-tasks`);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <ReactImageAnnotate
      labelImages
      regionClsList={classes}
      images={images}
      onExit={handleExit}
    />
  );
};

export default VerificationMakingPage;
