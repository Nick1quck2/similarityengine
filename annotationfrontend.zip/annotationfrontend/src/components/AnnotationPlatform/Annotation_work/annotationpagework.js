import React, { useState, useEffect } from "react";
import { useParams, useHistory } from "react-router-dom";
import axios from "axios";
import ReactImageAnnotate from "react-image-annotate";

const AnnotationMakingPage = () => {
  const { request_id, request_name, x_number, y_number, p_index, status } =
    useParams();
  const history = useHistory();
  const token = localStorage.getItem("access_token");
  const user = localStorage.getItem("username");

  const [classes, setClasses] = useState([]);
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(true);

  const [selectedImageIndex, setSelectedImageIndex] = useState(0); // Track current image index

  useEffect(() => {
    const fetchClasses = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8000/request/requestplatform/${request_id}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setClasses(response.data.data.classes || []);
      } catch (error) {
        console.error("Error fetching classes:", error);
      }
    };

    const fetchImages = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8000/request/images/${request_name}?x_number=${x_number}&y_number=${y_number}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        const imageList = response.data.data.map((image) => ({
          src: `http://localhost:8000/${image.url}`,
          name: image.filename,
        }));
        setImages(imageList);
      } catch (error) {
        console.error("Error fetching images:", error);
      }
    };

    const fetchData = async () => {
      setLoading(true);
      await fetchClasses();
      await fetchImages();
      setLoading(false);
    };

    fetchData();
  }, [request_id, request_name, x_number, y_number, token]);

  const handleSaveAnnotations = async (output) => {
    try {
      const xNum = parseInt(x_number, 10);
      const yNum = parseInt(y_number, 10);
      const imageRange = [...Array(yNum - xNum + 1).keys()].map((i) => i + xNum);

      const annotations = output.images
        .map((image, index) => {
          if (!image.regions || image.regions.length === 0) return null;
          return {
            Image_name: image.name,
            Image_number: imageRange[index],
            regions: image.regions.map((region) => ({
              id: region.id,
              class_name: region.cls,
              color: region.color,
              x: region.x,
              y: region.y,
              w: region.w,
              h: region.h,
            })),
          };
        })
        .filter((annotation) => annotation !== null);

      for (const annotation of annotations) {
        const date_annotated = new Date().toISOString().split("T")[0];

        const labelationResponse = await axios.post(
          `http://localhost:8000/request/labelation/?linked=${request_id}&Image_number=${annotation.Image_number}`,
          {
            linked: request_id,
            Image_name: annotation.Image_name,
            Image_number: annotation.Image_number,
            annotated_by: user,
            date_annotated: date_annotated,
          },
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        const labelationId = labelationResponse.data.data.id;

        for (const region of annotation.regions) {
          await axios.post(
            `http://localhost:8000/request/label-data/`,
            {
              linked: labelationId,
              class_name: region.class_name,
              color: region.color,
              region_id: region.id,
              x: region.x,
              y: region.y,
              w: region.w,
              h: region.h,
            },
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );
        }
      }
    } catch (error) {
      console.error("Error saving annotations:", error);
      alert("Failed to save annotations.");
    }
  };

  const handleNext = async (output) => {
    await handleSaveAnnotations(output);

    // Move to the next image if available
    setSelectedImageIndex((prevIndex) => {
      if (prevIndex < images.length - 1) {
        return prevIndex + 1;
      } else {
        alert("You have reached the last image!");
        return prevIndex;
      }
    });
  };

  const handleExit = () => {
    history.push(
      `/request_dashboard/${request_id}/${request_name}/${p_index}/${status}/annotation-tasks`
    );
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <>
      <ReactImageAnnotate
        labelImages
        regionClsList={classes}
        images={images}
        selectedImage={selectedImageIndex} // Pass the selected image index
        onNextImage={handleNext} // Save and move to the next image
        onExit={handleExit} // Navigate without saving
      />
    </>
  );
};

export default AnnotationMakingPage;
