import React from "react";
import ReactImageAnnotate from "react-image-annotate";

const App12 = () => (
  <ReactImageAnnotate
    labelImages
    regionClsList={["Alpha", "Beta", "Charlie", "Delta"]}
    regionTagList={["tag1", "tag2", "tag3"]}
    images={[
      {
        src: "https://cdn.britannica.com/37/154237-050-A76A506D/blue-peafowl-tail-Indian-peacock-courtship-displays.jpg",
        name: "Image 1",
        regions: [
          {
            id : "region1",
            type: "box",
            x: 0.08027144791850674,
            y: 0.25225225225225223,
            w: 0.2049034328446093,
            h: 0.3303303303303303,
            color: "#f44336",
            cls: "Alpha",
          }
          
        ],
      },
    ]}
  />

);

export default App12;
