from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save, post_delete,pre_delete , pre_save
from django.dispatch import receiver
from django.db import transaction

# Create your models here.
class Annotationclasses(models.Model):
    name = models.CharField( max_length=255)
    created_at = models.DateField(auto_now_add=True)
    def __str__(self) -> str:
        return f"{self.name}"
    
class RequestPlatform(models.Model):
    STATUS_CHOICES = [
        ('Running', 'Running Status'),
        ('Complete', 'Complete Status'),
        ('Pause', 'Pause Status'),
    ]
    request_name = models.CharField(max_length=255)
    task = models.TextField()
    classes = models.ManyToManyField(Annotationclasses)
    instructions = models.TextField()
    data_info = models.TextField()
    total_images = models.PositiveIntegerField(default=0)
    Assigned_annotation_images = models.PositiveIntegerField(default=0)
    Assigned_verification_images = models.PositiveIntegerField(default=0)
    Total_annotated = models.PositiveIntegerField(default=0)
    Total_verified = models.PositiveIntegerField(default=0)
    

    status = models.CharField(
        max_length=255,
        choices=STATUS_CHOICES,
        default='Running'
    )
    created_at = models.DateField(auto_now_add=True)

    
    def __str__(self) -> str:
        return f"{self.request_name}"

    # Django will auto-generate an auto-incrementing 'id' field



class Assign_Annotation_Tasks( models.Model):
    linked = models.ForeignKey(RequestPlatform , on_delete=models.CASCADE , null=True)
    x_number = models.PositiveBigIntegerField()
    y_number = models.PositiveIntegerField()
    total_images= models.PositiveIntegerField(default=0)
    all_annotators = models.ManyToManyField(User )
    created_at = models.DateField(auto_now_add=True)
    def save(self, *args, **kwargs):
        # Calculate total_images before saving 
        self.total_images = (self.y_number - self.x_number) + 1
        
        super().save(*args, **kwargs)
    def __str__(self) -> str:
        return f"{self.linked.request_name} annotation task {self.x_number} - {self.y_number}"



class Assign_Verification_Tasks( models.Model):
    linked = models.ForeignKey(RequestPlatform ,on_delete=models.CASCADE,null=True)
    x_number = models.PositiveBigIntegerField()
    y_number = models.PositiveIntegerField()
    total_images= models.PositiveIntegerField(default=0)
    all_verifiers = models.ManyToManyField(User )
    created_at = models.DateField(auto_now_add=True)
    def save(self, *args, **kwargs):
        # Calculate total_images before saving
        self.total_images = (self.y_number - self.x_number) + 1
        super().save(*args, **kwargs)
    def __str__(self) -> str:
        return f"{self.linked.request_name} verification task {self.x_number} - {self.y_number}"

    

class Task_Annotation_User(models.Model):
    linked = models.ForeignKey( Assign_Annotation_Tasks, on_delete=models.CASCADE,null=True  )
    user = models.ForeignKey(User , on_delete=models.SET_NULL,null=True )
    user_x_number  = models.PositiveIntegerField()
    user_y_number = models.PositiveIntegerField()
    total_images= models.PositiveIntegerField( default=0)
    
    created_at = models.DateField(auto_now_add=True)
    def save(self, *args, **kwargs):
        # Calculate total_images before saving
        self.total_images = (self.user_y_number - self.user_x_number) + 1
        super().save(*args, **kwargs)

    def __str__(self) -> str:
        return f"{self.user.username} have a annotation task on {self.user_x_number} - {self.user_y_number} of {self.linked}"



class Task_Verification_User(models.Model):
    linked = models.ForeignKey( Assign_Verification_Tasks, on_delete=models.CASCADE,null=True  )
    user = models.ForeignKey(User , on_delete=models.SET_NULL,null=True )
    user_x_number  = models.PositiveIntegerField()
    user_y_number = models.PositiveIntegerField()
    total_images= models.PositiveIntegerField(default=0)

    created_at = models.DateField(auto_now_add=True)
    def save(self, *args, **kwargs):
        # Calculate total_images before saving
        self.total_images = (self.user_y_number - self.user_x_number) + 1
        super().save(*args, **kwargs)

    def __str__(self) -> str:
        return f"{self.user.username} have a verification task on {self.user_x_number} - {self.user_y_number} of {self.linked.linked.request_name}"


class Track(models.Model):
    linked = models.ForeignKey(RequestPlatform , on_delete=models.CASCADE , null=True)
    Image_number = models.PositiveBigIntegerField()
    annotated = models.BooleanField(default=False)
    verified = models.PositiveBigIntegerField(default=0)
    created_at = models.PositiveBigIntegerField(default=0)

    
    def __str__(self):
        return f"Track of {self.linked.request_name} from {self.Image_number}"



#####(Images,labels) creation of request_name folder 
import os
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.conf import settings
from .models import RequestPlatform

@receiver(post_save, sender=RequestPlatform)
def create_folders(sender, instance, created, **kwargs):
    if created:
        base_path = os.path.join(settings.MEDIA_ROOT, instance.request_name)
        images_path = os.path.join(base_path, 'images')

        os.makedirs(images_path, exist_ok=True)
        
############################


class Labelation(models.Model):
    linked = models.ForeignKey(RequestPlatform ,on_delete=models.CASCADE,null=True)
    Image_name = models.TextField()
    Image_number = models.PositiveBigIntegerField(null=True, blank=True)
    annotated_by = models.ForeignKey(User, on_delete=models.SET_NULL  , null=True ,related_name='annotated_labels')
    verified_by = models.ForeignKey(User, on_delete=models.SET_NULL  ,   null=True, blank=True, related_name='verified_labels')
    date_annotated = models.DateField(null=True)
    date_verified = models.DateField(null=True)
    created_at = models.DateField(auto_now_add=True)
    def __str__(self) -> str:
        return f"{self.linked.request_name} ->Image number {self.Image_number}, by {self.annotated_by.username}"



class Label_data(models.Model):
    linked = models.ForeignKey(Labelation ,on_delete=models.CASCADE,null=True)
    class_name = models.ForeignKey(Annotationclasses,on_delete=models.SET_NULL,null=True)
    color = models.CharField(max_length=250,null=True)
    region_id  = models.CharField(max_length=250,null=True)
    x=models.FloatField() 
    y=models.FloatField() 
    w=models.FloatField()    
    h=models.FloatField()  
    created_at = models.DateField(auto_now_add=True)    
    def __str__(self) -> str:   
        return f"{self.linked.linked.request_name} ->Image number {self.linked.Image_number} -> {self.class_name.name}"





###########################signals work#############################





######

@receiver(post_save, sender=Assign_Annotation_Tasks)
def update_save_assigned_annotated(sender, instance, created, **kwargs):
    if created: 
        requestplatform = instance.linked
        instance.total_images
        requestplatform.Assigned_annotation_images  = (requestplatform.Assigned_annotation_images ) + ( instance.total_images)
        requestplatform.save()

@receiver(post_delete, sender=Assign_Annotation_Tasks)
def update_delete_assigned_annotated(sender, instance, **kwargs):
        requestplatform = instance.linked
        instance.total_images
        requestplatform.Assigned_annotation_images  = (requestplatform.Assigned_annotation_images ) - ( instance.total_images)
        requestplatform.save()



@receiver(post_save, sender=Assign_Verification_Tasks)
def update_save_assigned_verified(sender, instance, created, **kwargs):
    if created: 
        requestplatform = instance.linked
        instance.total_images
        requestplatform.Assigned_verification_images  = (requestplatform.Assigned_verification_images ) + ( instance.total_images)
        requestplatform.save()


@receiver(post_delete, sender=Assign_Verification_Tasks)
def update_delete_assigned_verified(sender, instance, **kwargs):
        requestplatform = instance.linked
        instance.total_images
        requestplatform.Assigned_verification_images  = (requestplatform.Assigned_verification_images ) - ( instance.total_images)
        requestplatform.save()



@receiver(pre_save, sender=Assign_Annotation_Tasks)
def prevent_duplicate_task1(sender, instance, **kwargs):
    # Check if an object with the same x_number, y_number, and linked already exists
    if Assign_Annotation_Tasks.objects.filter(
        linked=instance.linked,
        x_number=instance.x_number,
        y_number=instance.y_number
    ).exists():
        # Prevent saving the new task by raising a ValidationError
        raise ValueError("An annotation task with the same x_number and y_number already exists.")



@receiver(pre_save, sender=Assign_Verification_Tasks)
def prevent_duplicate_task2(sender, instance, **kwargs):
    # Check if an object with the same x_number, y_number, and linked already exists
    if Assign_Verification_Tasks.objects.filter(
        linked=instance.linked,
        x_number=instance.x_number,
        y_number=instance.y_number
    ).exists():
        # Prevent saving the new task by raising a ValidationError
        raise ValueError("An verification task with the same x_number and y_number already exists.")




@receiver(pre_save, sender=Task_Annotation_User)
def prevent_duplicate_task1_1(sender, instance, **kwargs):
    # Check if an object with the same x_number, y_number, and linked already exists
    if Task_Annotation_User.objects.filter(
        linked=instance.linked,
        user_x_number=instance.user_x_number,
        user_y_number=instance.user_y_number
    ).exists():
        # Prevent saving the new task by raising a ValidationError
        raise ValueError("An annotation task with the same x_number and y_number already exists.")


@receiver(pre_save, sender=Task_Verification_User)
def prevent_duplicate_task2_1(sender, instance, **kwargs):
    # Check if an object with the same x_number, y_number, and linked already exists
    if Task_Verification_User.objects.filter(
        linked=instance.linked,
        user_x_number=instance.user_x_number,
        user_y_number=instance.user_y_number
    ).exists():
        # Prevent saving the new task by raising a ValidationError
        raise ValueError("An verification task with the same x_number and y_number already exists.")


###############Tracking 
@receiver(pre_save, sender=Labelation)
def track1(sender, instance, **kwargs):
    """Track annotation and verification updates on Labelation creation or update."""
    # Determine if it's a new instance
    is_new = instance.id is None

    # Get the linked RequestPlatform
    request = instance.linked
    track , _ = Track.objects.get_or_create(linked = request , Image_number = instance.Image_number  )


    if not is_new:
        # Handle updates (if the instance is being updated)
        try:
            old_instance = Labelation.objects.get(id=instance.id)
            # Adjust totals for annotated_by changes
            if old_instance.annotated_by != instance.annotated_by:
                if old_instance.annotated_by:
                    request.Total_annotated -= 1
                if instance.annotated_by:
                    request.Total_annotated += 1

            # Adjust totals for verified_by changes
            if old_instance.verified_by != instance.verified_by:
                if old_instance.verified_by:
                    request.Total_verified -= 1
                if instance.verified_by:
                    request.Total_verified += 1
            
            

        except Labelation.DoesNotExist:
            pass  # This should not happen, but handle gracefully

    else:
        # Handle creation
        if instance.annotated_by:
            request.Total_annotated += 1
        if instance.verified_by:
            request.Total_verified += 1

    # Save the updated RequestPlatform
    request.Total_annotated = max(0, request.Total_annotated)  # Prevent negative values
    request.Total_verified = max(0, request.Total_verified)  # Prevent negative values
    request.save()
    if instance.annotated_by :
        track.annotated = 1
        track.save()
    if instance.verified_by :
        track.verified = 1
        track.save()


@receiver(pre_delete, sender=Labelation)
def track2(sender, instance, **kwargs):
    """Track annotation and verification updates on Labelation deletion."""
    request = instance.linked
    track,_ = Track.objects.get_or_create(linked = request , Image_number = instance.Image_number  )

    if instance.annotated_by:
        request.Total_annotated = max(0, request.Total_annotated - 1)  # Prevent negative values
    if instance.verified_by:
        request.Total_verified = max(0, request.Total_verified - 1)  # Prevent negative values
    request.save()
    if instance.annotated_by :
        track.annotated = 0
        track.save()
    if instance.verified_by :
        track.verified = 0
        track.save()