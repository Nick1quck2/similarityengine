from rest_framework import serializers
from .models import RequestPlatform, Annotationclasses,Assign_Annotation_Tasks, Task_Annotation_User,Assign_Verification_Tasks,Task_Verification_User
from django.contrib.auth.models import User
from .models import Labelation, Label_data
from rest_framework.exceptions import ValidationError

class AnnotationClassesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Annotationclasses
        fields = ['id', 'name', 'created_at']


class RequestPlatformSerializer(serializers.ModelSerializer):
    classes = serializers.SlugRelatedField(
        many=True,
        slug_field='name',
        queryset=Annotationclasses.objects.all()
    )

    class Meta:
        model = RequestPlatform
        fields = '__all__'




class AssignAnnotationTasksSerializer(serializers.ModelSerializer):
    linked = serializers.PrimaryKeyRelatedField(queryset=RequestPlatform.objects.all())  # Expect ID for the linked field
    all_annotators = serializers.SlugRelatedField(
        queryset=User.objects.all(),  # Queryset for validation
        slug_field='username',  # Use the `username` field instead of IDs
        many=True  # Support multiple annotators
    )

    class Meta:
        model = Assign_Annotation_Tasks
        fields = '__all__'


class TaskAnnotationUserSerializer(serializers.ModelSerializer):
    linked = serializers.PrimaryKeyRelatedField(queryset=Assign_Annotation_Tasks.objects.all())  # Expect ID for the linked field
    user =  serializers.SlugRelatedField(
        queryset=User.objects.all(),  # Required for validation during input
        slug_field='username'  # Use the `username` field instead of IDs
    )

    class Meta:
        model = Task_Annotation_User
        fields = '__all__'



class AssignVerificationTasksSerializer(serializers.ModelSerializer):
    linked = serializers.PrimaryKeyRelatedField(queryset=RequestPlatform.objects.all())  # Expect ID for the linked field
    all_verifiers = serializers.SlugRelatedField(
        queryset=User.objects.all(),  # Queryset for validation
        slug_field='username',  # Use the `username` field instead of IDs
        many=True  # Support multiple annotators
    )

    class Meta:
        model = Assign_Verification_Tasks
        fields = '__all__'


class TaskVerificationUserSerializer(serializers.ModelSerializer):
    linked = serializers.PrimaryKeyRelatedField(queryset=Assign_Verification_Tasks.objects.all())  # Expect ID for the linked field
    user = serializers.SlugRelatedField(
        queryset=User.objects.all(),  # Required for validation during input
        slug_field='username'  # Use the `username` field instead of IDs
    )
    class Meta:
        model = Task_Verification_User
        fields = '__all__'



class LabelationSerializer(serializers.ModelSerializer):
    linked = serializers.PrimaryKeyRelatedField(queryset=RequestPlatform.objects.all())

    annotated_by = serializers.SlugRelatedField(
        slug_field='username',  # Match by username
        queryset=User.objects.all(),
         allow_null=True,  # Allow null values
        required=False 
    )
    verified_by = serializers.SlugRelatedField(
        slug_field='username', 
        queryset=User.objects.all(),
        allow_null=True,  # Allow null values
        required=False 
    )

    class Meta:
        model = Labelation
        fields =  '__all__'


# Serializer for Label_data
class LabelDataSerializer(serializers.ModelSerializer):
    linked = serializers.PrimaryKeyRelatedField(queryset=Labelation.objects.all())
    class_name = serializers.CharField(source='class_name.name')  # Maps to `class_name.name`

    class Meta:
        model = Label_data
        fields = '__all__'

    def create(self, validated_data):
        # Extract and resolve `class_name.name` from the input data
        class_name_name = validated_data.pop('class_name')['name']

        # Fetch the Annotationclasses instance by the given name
        try:
            class_name_instance = Annotationclasses.objects.get(name=class_name_name)
        except Annotationclasses.DoesNotExist:
            raise ValidationError({"class_name": f"Class name '{class_name_name}' does not exist."})

        # Add the resolved instance back to the validated data
        validated_data['class_name'] = class_name_instance

        # Call the parent's create() method to save the object
        return super().create(validated_data)