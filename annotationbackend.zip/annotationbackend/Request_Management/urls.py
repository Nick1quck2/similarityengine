from django.urls import path
from . import views 
urlpatterns =[
   path('requestplatform/', views.RequestPlatformView.as_view()),  # For GET all and POST
    path('requestplatform/<int:pk>/', views.RequestPlatformView.as_view()), 
     path('api/annotationclasses/', views.AnnotationClassesViewSet.as_view({'get': 'list', 'post': 'create'}), name='annotation-classes-list-create'),
    path('api/annotationclasses/<int:pk>/', views.AnnotationClassesViewSet.as_view({'get': 'retrieve', 'put': 'update', 'delete': 'destroy'}), name='annotation-classes-detail'),
    path('images/<str:request_name>/', views.ImagesAPIView.as_view(), name='image-list'),
    path('images/<str:request_name>/<str:filename>/', views.ImagesAPIView.as_view(), name='image-detail'),

 path('assign-tasks/', views.AssignAnnotationTasksViewSet.as_view({
        'get': 'list',
        'post': 'create',
    })),
    path('assign-tasks/<int:pk>/', views.AssignAnnotationTasksViewSet.as_view({
        'get': 'retrieve',
        'put': 'update',
        'delete': 'destroy',
    })),
    path('task-users/', views.TaskAnnotationUserViewSet.as_view({
        'get': 'list',
        'post': 'create',
    })),
    path('task-users/<int:pk>/', views.TaskAnnotationUserViewSet.as_view({
        'get': 'retrieve',
        'put': 'update',
        'delete': 'destroy',
    })),




    path('assign_verification-tasks/', views.AssignVerificationTasksViewSet.as_view({
        'get': 'list',
        'post': 'create',
    })),
    path('assign_verification-tasks/<int:pk>/', views.AssignVerificationTasksViewSet.as_view({
        'get': 'retrieve',
        'put': 'update',
        'delete': 'destroy',
    })),

path('task_verification-users/', views.TaskVerificationUserViewSet.as_view({
        'get': 'list',
        'post': 'create',
    })),
    path('task_verification-users/<int:pk>/', views.TaskVerificationUserViewSet.as_view({
        'get': 'retrieve',
        'put': 'update',
        'delete': 'destroy',
    })),

         path('labelation/', views.LabelationAPIView.as_view(), name='labelation-list-create'),
    path('labelation/<int:pk>/', views.LabelationAPIView.as_view(), name='labelation-detail'),

    # Endpoints for Label_data
    path('label-data/', views.LabelDataAPIView.as_view(), name='label-data-list-create'),
    path('label-data/<int:pk>/', views.LabelDataAPIView.as_view(), name='label-data-detail'),
    path("api/label-data-summary/<int:request_id>/", views.label_data_summary, name="label_data_summary"),
        path("download/<int:request_id>/<str:download_type>/", views.download_annotations, name="download_annotations"),
    path('track-stats/', views.TrackStatsAPIView.as_view(), name='track-stats'),


      path('images1/<str:request_name>/', views.ImagesAPIView1.as_view(), name='image-list'),
    path('images1/<str:request_name>/<str:filename>/', views.ImagesAPIView1.as_view(), name='image-detail'),


]


