from django.urls import path
from . import views 

user_list = views.UserViewSet.as_view({
    'get': 'list',
    'post': 'create',
})

user_detail = views.UserViewSet.as_view({
    'get': 'retrieve',
    'put': 'update',
    'patch': 'partial_update',
    'delete': 'destroy',
})


urlpatterns =[

    path("login", views.login , name='login') ,

    path('', user_list, name='user-list'),           # List and create users
    path('<int:pk>/', user_detail, name='user-detail'), 
   
]